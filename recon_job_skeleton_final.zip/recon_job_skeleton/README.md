# Reconciliation Batch Job and Streaming Aggregator

This project contains two complementary Spring Boot applications that implement a tactical
reconciliation approach for a microservices ecosystem using PostgreSQL audit tables and
Kafka.  It is intended as a **step towards** a more event‑driven architecture but
provides an immediate solution without requiring any changes to existing services.

## Overview

When a business event (e.g. a trade instruction) flows through your microservices
pipeline it is processed by several services in sequence.  Each service inserts a
row into its audit table whenever it accepts or completes a step.  You want to
know that *all* steps have occurred for every trade and how long they take.

The simplest long‑term design is for each service to emit a small “lineage”
event to a Kafka topic as soon as it processes a trade.  Kafka is designed for
this model; producers publish events and consumers react asynchronously.  Events
with the same business key should be published to the **same topic and
partition** so that consumers see them in order【74504007537025†L350-L353】.  Having a
small number of topics and partitions also minimises latency and resource
overhead【74504007537025†L296-L310】.  However, if you cannot add lineage
emission to every microservice immediately, the batch job in this project
bridges the gap.

### Components

1. **ReconJobApplication** – a scheduled batch that polls the audit tables of
   each configured microservice every `scheduleIntervalMinutes` (default 10
   minutes).  It reads all new audit rows since the last run and publishes a
   `LineageMessage` to the `lineage.v1` Kafka topic for each row.  The record
   key is the `tradeId` so all events for a trade are co‑located on the same
   partition.  Each message contains:

   - `tradeId` – business correlation identifier
   - `serviceName` – originating microservice name
   - `step` – name of the step/event (e.g. `TRADE_OBJECT_CREATED`)
   - `status` – status reported by the microservice (e.g. `SUCCESS`, `FAILED`)
   - `timestamp` – event time from the audit row
   - `eventId` / `linkedEventId` – IDs for traceability (may be `null`)
   - `attributes` – optional map of enrichment fields (e.g. `soCount`)

2. **ReconAggregatorApplication** – a streaming service that consumes
   `LineageMessage` events in real time, maintains an in‑memory summary per
   `tradeId` and logs the overall status (`IN_PROGRESS`, `COMPLETE`, or
   `FAILED`) after each update.  You can extend this service to write
   summaries to a `recon.summary` topic, persist them in a database, or expose
   them via a REST API.

The two applications live in the same Maven module for demonstration purposes
but run independently – you may package them separately if desired.

## Configuration

Configuration lives in `src/main/resources/application.yml`.  You can override
any property via environment variables or Spring Boot’s conventional property
sources.  Key sections include:

```yaml
spring:
  kafka:
    bootstrap-servers: localhost:9092  # Kafka cluster connection

recon:
  schedule-interval-minutes: 10        # how often to poll each DB (in minutes)
  lineage-topic: lineage.v1            # topic to publish lineage events to
  expected-steps: TRADE_EVENT_PUBLISHED,TRADE_OBJECT_CREATED,SO_CREATED,FUNDING_SENT,ACCOUNTING_SENT
  microservices:
    - name: trade-ingestion
      jdbc-url: jdbc:h2:mem:trade_ingestion;MODE=PostgreSQL
      username: sa
      password: 
      audit-table: audit_trade_ingestion
      # Optional enrichment query to add additional attributes.  Must accept
      # :tradeIds parameter and return trade_id plus additional summary columns.
      # enrichment-query: SELECT trade_id, count(*) AS so_count FROM settlement_obligation WHERE trade_id IN (:tradeIds) GROUP BY trade_id
    - name: trade-consumer
      jdbc-url: jdbc:h2:mem:trade_consumer;MODE=PostgreSQL
      username: sa
      password: 
      audit-table: audit_trade_consumer
    - name: funding
      jdbc-url: jdbc:h2:mem:funding;MODE=PostgreSQL
      username: sa
      password: 
      audit-table: audit_funding
    - name: accounting
      jdbc-url: jdbc:h2:mem:accounting;MODE=PostgreSQL
      username: sa
      password: 
      audit-table: audit_accounting
```

### Defining microservice connections

For each microservice you must specify:

* **`name`** – a unique identifier (used for the recon state repository key).
* **`jdbc-url`**, **`username`** and **`password`** – to connect to the
  microservice’s database.  A new connection is created for each batch run; in
  production you would use a connection pool such as HikariCP.
* **`audit-table`** – the name of the table that records status changes.  This
  table must be append‑only and include at least the columns `id` (a
  monotonically increasing primary key), `trade_id`, `step`, `status`,
  `timestamp`, `event_id` and `linked_event_id`.  See `AuditRecord` for
  mapping.  Additional columns are ignored.
* **`enrichment-query`** (optional) – a SQL statement executed after
  collecting a batch of audit rows.  It must accept a named parameter
  `:tradeIds` and return at least a `trade_id` column plus any summary fields
  you wish to attach to the lineage message.  The enrichment results are
  merged into the `attributes` map of each lineage event.

### Checkpointing

The job stores the last processed audit ID for each microservice in
`ReconStateRepository`.  This implementation uses a concurrent map; replace it
with a persistent store (e.g. Postgres, Redis or a Kafka compacted topic) to
survive restarts.  A new run reads only rows where `id > lastId` and updates
the checkpoint after successful processing.  Using the monotonically
increasing `id` field simplifies incremental polling and avoids missing
records.

## Running locally

To run the batch job and aggregator locally:

1. Ensure Kafka is running on `localhost:9092` (you can start it with
   Docker Compose or use the Confluent CLI).  The default configuration uses
   an embedded H2 database for demonstration; replace the JDBC URLs with
   actual Postgres connections.
2. Build the project:

   ```sh
   mvn clean package
   ```

3. Start the batch job:

   ```sh
   java -cp target/recon-job-skeleton-0.0.1-SNAPSHOT.jar com.example.reconjob.ReconJobApplication
   ```

4. In a separate terminal, start the aggregator:

   ```sh
   java -cp target/recon-job-skeleton-0.0.1-SNAPSHOT.jar com.example.reconjob.aggregator.ReconAggregatorApplication
   ```

During startup the scheduler logs how many microservices it will poll and how
often.  On each run it logs the number of audit rows processed and publishes
lineage messages.  The aggregator logs each update with the overall status
(`IN_PROGRESS`, `COMPLETE` or `FAILED`) for the corresponding trade ID.

## Generating a report

To generate a simple report you can extend `ReconSummaryService` to write
summaries to a database or a file.  The current implementation keeps
in‑memory summaries and exposes them via the `getSummaries()` method.
Possible approaches include:

* **Kafka Streams summary topic** – after processing each lineage message,
  publish a `ReconSummary` record keyed by `tradeId` to a `recon.summary.v1`
  topic.  Downstream consumers can subscribe and materialise a summary table
  or generate daily reports.
* **REST API** – create a REST controller that injects `ReconSummaryService`
  and returns the summaries as JSON.  A scheduled task could periodically
  serialise the summaries to a CSV for auditors.
* **Database table** – persist the summary state into Postgres.  This makes it
  easy to query for all trades in a given status or time window.

## Extending the pipeline

When a new microservice is added to the chain you only need to:

1. Add a new entry under `recon.microservices` with its database connection
   details and `audit-table` name.
2. Update `recon.expected-steps` if the new service emits a new step that is
   required for a trade to be considered complete.  For example:
   `expected-steps: TRADE_EVENT_PUBLISHED,TRADE_OBJECT_CREATED,SO_CREATED,NETTING_COMPLETED,FUNDING_SENT,ACCOUNTING_SENT`.
3. Optionally supply an `enrichment-query` if the new service writes
   additional summary information you want to include.
4. No code changes are required in the recon job or aggregator; they
   dynamically pick up the new configuration.

In the long term you can replace the batch job with service‑emitted lineage
events.  Each microservice would publish a small audit record to the lineage
topic when it processes a trade.  This change removes database polling,
reduces coupling and leverages Kafka’s durable event log for replay and
ordering guarantees【74504007537025†L350-L353】.  You can use Debezium as an
intermediate step to capture audit tables via CDC without writing code,
or adopt Single Message Transforms in Kafka Connect to route table changes to
the lineage topic【150202194210486†L956-L980】.

## References

* **Ordering and topic guidelines:** Confluent’s event design guidelines note
  that events related to the same entity should be published to a single
  topic and partition so that consumers see them in order【74504007537025†L350-L353】.  It
  also warns that having too many small topics/partitions can increase
  latency and resource usage【74504007537025†L296-L310】.
* **Kafka Connect overview:** Kafka Connect runs connectors as
  independent tasks managed by the Connect framework; they are
  configured via JSON and do not require embedding code in your
  microservices【150202194210486†L956-L980】.
* **Debezium topic routing:** Debezium’s logical table routing SMT can route
  multiple tables into a single Kafka topic while preserving key/partition
  semantics【133289977515729†L172-L175】.