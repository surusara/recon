package com.example.reconjob.service;

import com.example.reconjob.model.LineageMessage;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.SendResult;
import org.springframework.stereotype.Component;
import org.springframework.util.concurrent.ListenableFuture;
import org.springframework.util.concurrent.ListenableFutureCallback;

/**
 * Publishes lineage events to a Kafka topic.  The topic name and the
 * {@link KafkaTemplate} are injected from the Spring context.  The record key
 * is the tradeId so that all events for a given trade go to the same partition.
 */
@Component
@RequiredArgsConstructor
@Slf4j
public class LineageMessagePublisher {

    private final KafkaTemplate<String, LineageMessage> kafkaTemplate;

    @Value("${recon.lineage-topic:lineage.v1}")
    private String lineageTopic;

    /**
     * Publish a lineage message to Kafka.  Success and failure of the
     * asynchronous send are logged.  In a production implementation you might
     * want to add retry logic or DLQ handling.
     *
     * @param message lineage event to publish
     */
    public void publish(LineageMessage message) {
        String key = message.getTradeId();
        ListenableFuture<SendResult<String, LineageMessage>> future =
                kafkaTemplate.send(lineageTopic, key, message);
        future.addCallback(new ListenableFutureCallback<>() {
            @Override
            public void onSuccess(SendResult<String, LineageMessage> result) {
                log.debug("Published lineage message for trade {} step {}", message.getTradeId(), message.getStep());
            }

            @Override
            public void onFailure(Throwable ex) {
                log.error("Failed to publish lineage message for trade {} step {}", message.getTradeId(), message.getStep(), ex);
            }
        });
    }
}