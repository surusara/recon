package com.example.reconjob.aggregator;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.kafka.annotation.EnableKafka;

/**
 * Separate Spring Boot entry point for the real‑time reconciliation aggregator.
 *
 * <p>The batch job publishes individual lineage messages keyed by trade ID to the
 * {@code lineage.v1} topic.  This streaming application consumes those messages,
 * updates an in‑memory state machine per trade and logs summary information.
 * You can run this application independently from the batch job by executing
 * {@code ReconAggregatorApplication} from your IDE or build tool.  See the
 * README for details.</p>
 */
@SpringBootApplication
@EnableKafka
public class ReconAggregatorApplication {

    public static void main(String[] args) {
        SpringApplication.run(ReconAggregatorApplication.class, args);
    }
}