package com.example.reconjob.service;

import com.example.reconjob.config.MicroserviceConfig;
import com.example.reconjob.config.ReconProperties;
import com.example.reconjob.config.ReconStateRepository;
import com.example.reconjob.model.AuditRecord;
import com.example.reconjob.model.LineageMessage;
import jakarta.annotation.PostConstruct;
import java.util.List;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

/**
 * Scheduled batch job that polls audit tables from all configured microservices
 * and publishes lineage events to Kafka.  The schedule interval is driven
 * by the {@code recon.scheduleIntervalMinutes} property (default 10 minutes).
 *
 * The job maintains its own high‑water mark per microservice in an in‑memory
 * repository so that each batch only processes new rows.  In a production
 * implementation you would persist these offsets to a durable store.
 */
@Component
@RequiredArgsConstructor
@Slf4j
public class ReconScheduler {

    private final ReconProperties reconProperties;
    private final ReconStateRepository stateRepository;
    private final AuditReaderService auditReaderService;
    private final LineageMessagePublisher lineagePublisher;

    @PostConstruct
    public void logStartup() {
        log.info("Recon scheduler initialised: running every {} minutes for {} microservices",
                reconProperties.getScheduleIntervalMinutes(),
                reconProperties.getMicroservices().size());
    }

    @Scheduled(fixedDelayString = "#{@reconProperties.scheduleIntervalMinutes * 60 * 1000}")
    public void runBatch() {
        log.info("Starting recon batch run");
        for (MicroserviceConfig cfg : reconProperties.getMicroservices()) {
            try {
                long lastId = stateRepository.getLastProcessedId(cfg.getName());
                List<AuditRecord> records = auditReaderService.readNewAuditRecords(cfg, lastId);
                if (!records.isEmpty()) {
                    long maxId = lastId;
                    for (AuditRecord record : records) {
                        // Convert to lineage message
                        LineageMessage msg = LineageMessage.builder()
                                .tradeId(record.getTradeId())
                                .serviceName(record.getServiceName())
                                .step(record.getStep())
                                .status(record.getStatus())
                                .timestamp(record.getTimestamp())
                                .eventId(record.getEventId())
                                .linkedEventId(record.getLinkedEventId())
                                .attributes(record.getAttributes())
                                .build();
                        lineagePublisher.publish(msg);
                        if (record.getId() > maxId) {
                            maxId = record.getId();
                        }
                    }
                    stateRepository.setLastProcessedId(cfg.getName(), maxId);
                    log.info("Processed {} audit records for {} (new lastId={})", records.size(), cfg.getName(), maxId);
                } else {
                    log.debug("No new audit records for {}", cfg.getName());
                }
            } catch (Exception e) {
                log.error("Error processing microservice {}", cfg.getName(), e);
            }
        }
        log.info("Recon batch run completed");
    }
}