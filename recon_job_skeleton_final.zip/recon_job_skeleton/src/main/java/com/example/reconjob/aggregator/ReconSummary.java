package com.example.reconjob.aggregator;

import java.time.Instant;
import java.util.HashMap;
import java.util.Map;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Aggregated per‑trade summary state.  The recon aggregator builds an
 * instance of this class for each unique trade ID it sees on the lineage
 * topic.  Each call to {@code update} will update the step status and
 * timestamp maps based on the incoming event and compute an overall
 * reconciliation status.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ReconSummary {

    /**
     * The unique business identifier for a trade.  This is used as the key
     * for the lineage and summary topics.
     */
    private String tradeId;

    /**
     * Map of step name to the latest status received for that step.  Step
     * names correspond to microservice events (e.g. TRADE_EVENT_PUBLISHED,
     * TRADE_OBJECT_CREATED, SO_CREATED, FUNDING_SENT_TO_MQ, etc.).
     */
    private Map<String, String> stepStatus = new HashMap<>();

    /**
     * Map of step name to the timestamp when that step was last observed.
     */
    private Map<String, Instant> stepTimestamp = new HashMap<>();

    /**
     * Sets the status and timestamp for a step.  If the status for a step
     * is already SUCCESS or FAILED, subsequent updates to that step will
     * overwrite the timestamp but not downgrade a SUCCESS to IN_PROGRESS.
     *
     * @param step the step name
     * @param status the latest status string
     * @param ts the event timestamp
     */
    public void updateStep(String step, String status, Instant ts) {
        if (step == null) {
            return;
        }
        String currentStatus = stepStatus.get(step);
        if (currentStatus == null || !"SUCCESS".equalsIgnoreCase(currentStatus) && !"FAILED".equalsIgnoreCase(currentStatus)) {
            stepStatus.put(step, status);
        }
        stepTimestamp.put(step, ts);
    }

    /**
     * Determines a high‑level reconciliation status for this trade.
     *
     * <p>The algorithm is intentionally simple: if any step has status
     * FAILED then the overall status is FAILED.  Otherwise, if all
     * expected steps are present and marked SUCCESS then the status is
     * COMPLETE.  If some steps are missing then the status is IN_PROGRESS.
     * The list of expected steps can be configured via the recon
     * aggregator configuration.</p>
     *
     * @param expectedSteps all steps that must eventually be processed for the trade
     * @return one of FAILED, COMPLETE, or IN_PROGRESS
     */
    public String determineStatus(Iterable<String> expectedSteps) {
        // If any step has FAILED status, the whole trade is failed.
        for (String status : stepStatus.values()) {
            if ("FAILED".equalsIgnoreCase(status)) {
                return "FAILED";
            }
        }
        boolean allPresent = true;
        for (String step : expectedSteps) {
            String s = stepStatus.get(step);
            if (s == null || !"SUCCESS".equalsIgnoreCase(s)) {
                allPresent = false;
                break;
            }
        }
        return allPresent ? "COMPLETE" : "IN_PROGRESS";
    }
}