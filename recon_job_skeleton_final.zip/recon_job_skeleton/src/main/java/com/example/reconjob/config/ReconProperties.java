package com.example.reconjob.config;

import java.util.ArrayList;
import java.util.List;
import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.bind.DefaultValue;
import org.springframework.context.annotation.Configuration;

/**
 * Top‑level configuration properties for the reconciliation batch job.  The YAML
 * file can define multiple microservice configurations under the {@code recon.microservices}
 * list.  You can also control the schedule interval in minutes via
 * {@code recon.scheduleIntervalMinutes}.
 */
@Configuration
@ConfigurationProperties(prefix = "recon")
@Data
public class ReconProperties {

    /**
     * Interval between batch runs in minutes.  Defaults to 10.  The scheduler
     * uses this value to trigger polling of the audit tables.
     */
    private long scheduleIntervalMinutes = 10;

    /**
     * List of microservice configurations.  Each entry corresponds to one
     * database to poll.
     */
    private List<MicroserviceConfig> microservices = new ArrayList<>();
}