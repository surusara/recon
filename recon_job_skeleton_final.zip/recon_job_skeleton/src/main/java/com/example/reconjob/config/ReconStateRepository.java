package com.example.reconjob.config;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import org.springframework.stereotype.Component;

/**
 * Simple in‑memory repository that tracks the last processed audit record ID for each
 * microservice.  In a production implementation you would persist this state to
 * a database or external store so that it survives restarts.  For this example
 * we store the values in a concurrent map keyed by microservice name.
 */
@Component
public class ReconStateRepository {

    private final Map<String, Long> lastProcessedId = new ConcurrentHashMap<>();

    /**
     * Retrieve the last processed audit ID for a microservice.  Returns 0 if no
     * value has been stored yet.
     *
     * @param serviceName name of the microservice
     * @return last processed ID or 0
     */
    public long getLastProcessedId(String serviceName) {
        return lastProcessedId.getOrDefault(serviceName, 0L);
    }

    /**
     * Store the last processed audit ID for a microservice.
     *
     * @param serviceName name of the microservice
     * @param lastId last processed ID
     */
    public void setLastProcessedId(String serviceName, long lastId) {
        lastProcessedId.put(serviceName, lastId);
    }
}