package com.example.reconjob.service;

import com.example.reconjob.config.MicroserviceConfig;
import com.example.reconjob.model.AuditRecord;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.Instant;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;
import javax.sql.DataSource;
import lombok.extern.slf4j.Slf4j;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.stereotype.Service;

/**
 * Service responsible for reading audit records from a microservice database.  This
 * implementation uses a {@link DriverManagerDataSource} per invocation based on
 * the configuration.  In a more robust implementation you would maintain a
 * connection pool per microservice using HikariCP.  For simplicity, this
 * example opens a new connection on each batch run.
 */
@Service
@Slf4j
public class AuditReaderService {

    private static final String AUDIT_SELECT_TEMPLATE =
            "SELECT id, trade_id, step, status, timestamp, event_id, linked_event_id " +
            "FROM %s WHERE id > ? ORDER BY id ASC";

    /**
     * Read all audit records with an ID greater than {@code lastId} for the given
     * microservice.  Optionally enrich the records by executing the configured
     * enrichment query.
     *
     * @param cfg microservice configuration
     * @param lastId last processed audit ID
     * @return list of audit records
     */
    public List<AuditRecord> readNewAuditRecords(MicroserviceConfig cfg, long lastId) {
        JdbcTemplate jdbcTemplate = new JdbcTemplate(createDataSource(cfg));
        String sql = String.format(AUDIT_SELECT_TEMPLATE, cfg.getAuditTable());
        List<AuditRecord> records = jdbcTemplate.query(sql, new Object[]{lastId}, new AuditRecordRowMapper(cfg));
        // Perform enrichment if configured
        if (cfg.getEnrichmentQuery() != null && !cfg.getEnrichmentQuery().isBlank() && !records.isEmpty()) {
            applyEnrichment(cfg, records);
        }
        return records;
    }

    private DataSource createDataSource(MicroserviceConfig cfg) {
        DriverManagerDataSource ds = new DriverManagerDataSource();
        ds.setUrl(cfg.getJdbcUrl());
        ds.setUsername(cfg.getUsername());
        ds.setPassword(cfg.getPassword());
        return ds;
    }

    private void applyEnrichment(MicroserviceConfig cfg, List<AuditRecord> records) {
        // Build a list of distinct trade IDs
        Set<String> tradeIds = records.stream().map(AuditRecord::getTradeId).collect(Collectors.toSet());
        NamedParameterJdbcTemplate namedJdbc = new NamedParameterJdbcTemplate(createDataSource(cfg));
        MapSqlParameterSource params = new MapSqlParameterSource();
        params.addValue("tradeIds", tradeIds);
        List<Map<String, Object>> rows = namedJdbc.queryForList(cfg.getEnrichmentQuery(), params);
        // Convert to map by tradeId
        Map<String, Map<String, Object>> byTrade = new HashMap<>();
        for (Map<String, Object> row : rows) {
            Object tradeIdObj = row.get("trade_id");
            if (tradeIdObj != null) {
                byTrade.put(tradeIdObj.toString(), row);
            }
        }
        // Attach enrichment results
        for (AuditRecord r : records) {
            Map<String, Object> summary = byTrade.get(r.getTradeId());
            if (summary != null) {
                if (r.getAttributes() == null) {
                    r.setAttributes(new HashMap<>());
                }
                // copy all keys except trade_id into attributes
                for (Map.Entry<String, Object> entry : summary.entrySet()) {
                    if (!"trade_id".equals(entry.getKey())) {
                        r.getAttributes().put(entry.getKey(), entry.getValue());
                    }
                }
            }
        }
    }

    /**
     * Maps result set rows to {@link AuditRecord}.  The microservice name is
     * injected from the configuration so it doesn’t need to be stored in the DB.
     */
    private static class AuditRecordRowMapper implements RowMapper<AuditRecord> {
        private final MicroserviceConfig cfg;

        AuditRecordRowMapper(MicroserviceConfig cfg) {
            this.cfg = cfg;
        }

        @Override
        public AuditRecord mapRow(ResultSet rs, int rowNum) throws SQLException {
            return AuditRecord.builder()
                    .id(rs.getLong("id"))
                    .tradeId(rs.getString("trade_id"))
                    .step(rs.getString("step"))
                    .status(rs.getString("status"))
                    .timestamp(rs.getTimestamp("timestamp").toInstant())
                    .eventId(rs.getString("event_id"))
                    .linkedEventId(rs.getString("linked_event_id"))
                    .serviceName(cfg.getName())
                    .attributes(null)
                    .build();
        }
    }
}