package com.example.reconjob;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Entry point for the reconciliation batch job and streaming application.  This application
 * can be run as a Spring Boot service.  The batch scheduler reads audit tables from
 * multiple microservices every 10 minutes, publishes lineage events to a Kafka topic,
 * and a Kafka Streams aggregator consumes those events to compute per-trade summaries.
 */
import org.springframework.scheduling.annotation.EnableScheduling;

@SpringBootApplication
@EnableScheduling
public class ReconJobApplication {

    public static void main(String[] args) {
        SpringApplication.run(ReconJobApplication.class, args);
    }
}