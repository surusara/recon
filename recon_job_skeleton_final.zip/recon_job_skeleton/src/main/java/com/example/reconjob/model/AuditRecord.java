package com.example.reconjob.model;

import java.time.Instant;
import java.util.Map;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Represents a single row from an audit table.  Each status change for a trade
 * results in an insert into the audit table.  The fields included here are the
 * minimum necessary for reconciliation.  You can add arbitrary additional
 * attributes as needed via the {@code attributes} map; these will be copied
 * into the lineage message.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AuditRecord {
    private long id;
    private String tradeId;
    private String step;
    private String status;
    private Instant timestamp;
    private String eventId;
    private String linkedEventId;
    private String serviceName;
    /**
     * Optional additional attributes to include in the lineage event.  This map
     * can contain values like {@code soCount} or other summary information
     * computed by the recon batch job.
     */
    private Map<String, Object> attributes;
}