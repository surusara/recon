package com.example.reconjob.aggregator;

import com.example.reconjob.model.LineageMessage;
import java.time.Instant;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

/**
 * Consumes lineage messages from Kafka, maintains per‑trade reconciliation
 * state and logs summary information.  For real deployments you could
 * instead publish updated summaries to a separate topic or persist them in
 * a database for reporting.
 */
@Slf4j
@Service
public class ReconSummaryService {

    /**
     * A concurrent map keyed by tradeId.  Each entry holds the current
     * reconciliation summary for that trade.  The map is unbounded but
     * entries will eventually be removed by the TTL eviction thread.
     */
    private final Map<String, ReconSummary> summaries = new ConcurrentHashMap<>();

    /**
     * The list of expected steps for a trade.  This list is used when
     * computing the high‑level status (COMPLETE, IN_PROGRESS, FAILED).  It
     * should be configured to include every step that your microservice
     * ecosystem produces lineage events for.  Additional steps will be
     * tracked dynamically but ignored for status computation.
     */
    private final List<String> expectedSteps;

    public ReconSummaryService(@Value("${recon.expected-steps:TRADE_EVENT_PUBLISHED,TRADE_OBJECT_CREATED,SO_CREATED,FUNDING_SENT,ACCOUNTING_SENT}") String expectedStepsProperty) {
        // Split the comma‑separated property into a list.  Trim whitespace.
        String[] parts = expectedStepsProperty.split(",");
        for (int i = 0; i < parts.length; i++) {
            parts[i] = parts[i].trim();
        }
        expectedSteps = Collections.unmodifiableList(Arrays.asList(parts));
        log.info("Recon aggregator expected steps: {}", expectedSteps);
    }

    /**
     * Kafka listener for lineage messages.  Each message updates the
     * corresponding summary.  This listener assumes the {@code tradeId} is
     * used as the record key; if not then the tradeId from the message
     * value will still be used as the lookup key.  After updating the
     * summary the method logs the current high‑level status for the trade.
     *
     * @param message the lineage event
     * @param partition the partition this record was read from (used in logs)
     * @param offset the offset of the record in the partition
     */
    @KafkaListener(
            topics = "${recon.lineage-topic:lineage.v1}",
            containerFactory = "lineageKafkaListenerContainerFactory",
            groupId = "recon-aggregator"
    )
    public void onLineageMessage(LineageMessage message, @org.springframework.messaging.handler.annotation.Header(name = "kafka_receivedPartitionId") int partition, @org.springframework.messaging.handler.annotation.Header(name = "kafka_offset") long offset) {
        if (message == null) {
            return;
        }
        String tradeId = message.getTradeId();
        if (tradeId == null) {
            log.warn("Received lineage message with null tradeId at partition {} offset {}: {}", partition, offset, message);
            return;
        }
        // Fetch or create summary for this trade
        ReconSummary summary = summaries.computeIfAbsent(tradeId, id -> {
            ReconSummary s = new ReconSummary();
            s.setTradeId(id);
            return s;
        });
        // Use event timestamp if present, else current time
        Instant ts = message.getTimestamp() != null ? message.getTimestamp() : Instant.now();
        summary.updateStep(message.getStep(), message.getStatus(), ts);
        // Determine overall status
        String overall = summary.determineStatus(expectedSteps);
        // Log the update.  For demonstration we just log; in a real system you
        // would publish a summary update to Kafka or persist in a database.
        log.info("[tradeId={}] Step {}={} at {}. Overall status: {}", tradeId, message.getStep(), message.getStatus(), ts, overall);
    }

    /**
     * Returns an immutable view of the current reconciliation summaries.  This
     * method could be exposed via a REST controller for ad‑hoc queries or
     * used in scheduled report generation.
     *
     * @return current recon summaries keyed by tradeId
     */
    public Map<String, ReconSummary> getSummaries() {
        return Collections.unmodifiableMap(summaries);
    }
}