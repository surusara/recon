package com.example.reconjob.config;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

/**
 * Represents the configuration for a single microservice database.  Each microservice
 * writes audit records to a dedicated table.  This configuration captures the JDBC
 * connection details and the audit table name.  Optionally, a microservice can
 * configure a SQL statement to compute additional summary information (e.g. number of
 * settlement obligations) based on the trades in the audit table.  Such queries
 * should be written to return a result keyed by trade_id.
 */
@Data
public class MicroserviceConfig {

    /** Human‑readable name of the microservice. */
    @NotBlank
    private String name;

    /** JDBC URL of the microservice’s database. */
    @NotBlank
    private String jdbcUrl;

    /** Username for the microservice’s database. */
    @NotBlank
    private String username;

    /** Password for the microservice’s database. */
    @NotBlank
    private String password;

    /** Name of the audit table to poll. */
    @NotBlank
    private String auditTable;

    /**
     * Optional SQL to compute additional enrichment.  For example, a statement like:
     *   SELECT trade_id, COUNT(*) AS so_count FROM settlement_obligation WHERE trade_id IN (:tradeIds) GROUP BY trade_id
     * The query must accept a parameter named tradeIds (supported by JdbcTemplate) and return columns
     * trade_id and so_count.  The recon batch job will use this SQL to enrich lineage events.
     */
    private String enrichmentQuery;
}