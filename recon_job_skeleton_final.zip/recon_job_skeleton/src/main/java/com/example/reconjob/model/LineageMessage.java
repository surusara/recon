package com.example.reconjob.model;

import java.time.Instant;
import java.util.Map;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * A lineage message encapsulates the minimal information required by the
 * reconciliation stream to determine that a given trade has reached a
 * particular step within a microservice.  Messages are published to the
 * {@code lineage.v1} topic.  The Kafka record key should be the {@code tradeId}
 * so that all events for a given trade are processed in order by the
 * downstream recon aggregator.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class LineageMessage {
    private String tradeId;
    private String serviceName;
    private String step;
    private String status;
    private Instant timestamp;
    private String eventId;
    private String linkedEventId;
    private Map<String, Object> attributes;
}