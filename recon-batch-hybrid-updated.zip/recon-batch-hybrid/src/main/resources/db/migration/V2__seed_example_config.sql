-- Example flows (edit to your real list)
INSERT INTO recon_expected_flow(flow_name, required, effective_from)
VALUES
  ('trade_ingestion', true, CURRENT_DATE),
  ('trade_consumer', true, CURRENT_DATE),
  ('settlement_obligation', true, CURRENT_DATE),
  ('confirmation', true, CURRENT_DATE),
  ('funding', true, CURRENT_DATE),
  ('accounting', true, CURRENT_DATE)
ON CONFLICT DO NOTHING;

-- Example source config (edit host/db/table/sql)
INSERT INTO recon_source_config(source_name, db_host, db_port, db_name, jdbc_params, audit_table, incremental_sql_template, batch_size, enabled)
VALUES
(
  'trade_ingestion',
  'microservice-db-host',
  5432,
  'trade_ingestion_db',
  '?sslmode=require',
  'trade_ingestion_audit',
  $$
  SELECT
    id AS src_audit_id,
    trade_date AS trade_date,
    event_id AS trade_id,
    event_version AS version,
    'trade_ingestion'::text AS flow_name,
    status AS status,
    proc_ms AS proc_ms,
    created_at AS created_at
  FROM trade_ingestion_audit
  WHERE id > ${last_seen_id}
    AND trade_date = DATE '${business_date}'
  ORDER BY id
  LIMIT ${limit}
  $$,
  200000,
  true
)
ON CONFLICT (source_name) DO NOTHING;

INSERT INTO recon_checkpoint(source_name, last_seen_id)
VALUES ('trade_ingestion', 0)
ON CONFLICT DO NOTHING;
