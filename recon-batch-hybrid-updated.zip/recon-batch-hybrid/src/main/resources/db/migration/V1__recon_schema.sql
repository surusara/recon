-- Central recon tables
CREATE TABLE IF NOT EXISTS recon_event (
  trade_date       date        NOT NULL,
  trade_id         text        NOT NULL,
  version          int         NOT NULL,
  flow_name        text        NOT NULL,
  status           text        NOT NULL,
  proc_ms          bigint      NULL,
  created_at       timestamptz NOT NULL DEFAULT now(),
  src_audit_id     bigint      NOT NULL
) PARTITION BY RANGE (trade_date);

CREATE TABLE IF NOT EXISTS recon_checkpoint (
  source_name   text PRIMARY KEY,
  last_seen_id  bigint NOT NULL,
  updated_at    timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS recon_expected_flow (
  flow_name      text NOT NULL,
  required       boolean NOT NULL DEFAULT true,
  effective_from date NOT NULL DEFAULT CURRENT_DATE,
  effective_to   date NULL,
  PRIMARY KEY(flow_name, effective_from)
);

-- Config describing each microservice source
CREATE TABLE IF NOT EXISTS recon_source_config (
  source_name             text PRIMARY KEY,
  db_host                 text NOT NULL,
  db_port                 int  NOT NULL DEFAULT 5432,
  db_name                 text NOT NULL,
  jdbc_params             text NULL, -- e.g. '?sslmode=require'
  audit_table             text NOT NULL,
  incremental_sql_template text NOT NULL,
  batch_size              int  NOT NULL DEFAULT 500000,
  enabled                 boolean NOT NULL DEFAULT true
);

-- Partition helper: create daily partition if absent
CREATE OR REPLACE FUNCTION ensure_recon_partition(p_trade_date date)
RETURNS void
LANGUAGE plpgsql
AS $$
DECLARE
  part_name text;
  start_date date;
  end_date date;
BEGIN
  start_date := p_trade_date;
  end_date := p_trade_date + INTERVAL '1 day';
  part_name := 'recon_event_' || to_char(start_date, 'YYYY_MM_DD');

  IF NOT EXISTS (
    SELECT 1 FROM pg_class c
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE c.relname = part_name
      AND n.nspname = current_schema()
  ) THEN
    EXECUTE format('CREATE TABLE %I PARTITION OF recon_event FOR VALUES FROM (%L) TO (%L)',
                   part_name, start_date, end_date);

    EXECUTE format('CREATE INDEX %I ON %I (trade_date, trade_id, version)',
                   'ix_'||part_name||'_day_trade', part_name);
    EXECUTE format('CREATE INDEX %I ON %I (trade_date, flow_name)',
                   'ix_'||part_name||'_day_flow', part_name);
  END IF;
END $$;

-- Drop partitions older than cutoff (exclusive). Returns number dropped.
CREATE OR REPLACE FUNCTION drop_recon_partitions_older_than(p_cutoff date)
RETURNS int
LANGUAGE plpgsql
AS $$
DECLARE
  r record;
  dropped int := 0;
  part_date date;
BEGIN
  FOR r IN
    SELECT c.relname AS part_name
    FROM pg_inherits i
    JOIN pg_class p ON p.oid = i.inhparent
    JOIN pg_class c ON c.oid = i.inhrelid
    WHERE p.relname = 'recon_event'
  LOOP
    -- Expect partition names recon_event_YYYY_MM_DD
    BEGIN
      part_date := to_date(substring(r.part_name from 12), 'YYYY_MM_DD');
      IF part_date < p_cutoff THEN
        EXECUTE format('DROP TABLE IF EXISTS %I', r.part_name);
        dropped := dropped + 1;
      END IF;
    EXCEPTION WHEN others THEN
      -- ignore unexpected names
      CONTINUE;
    END;
  END LOOP;

  RETURN dropped;
END $$;
