package com.ubs.recon.service;

import com.azure.storage.blob.BlobContainerClient;
import com.azure.storage.blob.specialized.BlockBlobClient;
import com.azure.storage.blob.specialized.BlobOutputStream;
import org.postgresql.PGConnection;
import org.postgresql.copy.CopyManager;
import org.springframework.stereotype.Service;

import javax.sql.DataSource;
import java.sql.Connection;
import java.time.LocalDate;

import static com.ubs.recon.config.AzureBlobConfig.blockBlob;

@Service
public class PgCopyToBlobExporter {

  private final DataSource reconDataSource;
  private final BlobContainerClient containerClient;

  public PgCopyToBlobExporter(DataSource reconDataSource, BlobContainerClient containerClient) {
    this.reconDataSource = reconDataSource;
    this.containerClient = containerClient;
  }

  public void exportUnmatched(LocalDate tradeDate, String blobPath) throws Exception {
    String sql = buildCopySql(tradeDate, true);
    copyOutToBlob(sql, blobPath);
  }

  public void exportEndOfDay(LocalDate tradeDate, String blobPath) throws Exception {
    String sql = buildCopySql(tradeDate, false);
    copyOutToBlob(sql, blobPath);
  }

  private void copyOutToBlob(String copySql, String blobPath) throws Exception {
    BlockBlobClient blob = blockBlob(containerClient, blobPath);

    try (Connection conn = reconDataSource.getConnection()) {
      conn.setAutoCommit(false);
      PGConnection pgConn = conn.unwrap(PGConnection.class);
      CopyManager copyManager = pgConn.getCopyAPI();

      try (BlobOutputStream out = blob.getBlobOutputStream(true)) {
        copyManager.copyOut(copySql, out);
        out.flush();
      }

      conn.commit();
    }
  }

  /**
   * COPY exports per trade row:
   * trade_date, trade_id, version, final_status, total_proc_ms, per_flow_proc_ms_json, missing_required_flows
   *
   * NOTE: This assumes recon_event already contains trade_id+version for all flows.
   * For fan-out flows (SO-level), you'd extend this SQL to aggregate child entities into trade-level status.
   */
  private String buildCopySql(LocalDate tradeDate, boolean unmatchedOnly) {

    String filterUnmatched = unmatchedOnly ? "WHERE final_status = 'UNMATCHED'" : "";

    return "COPY ( " +
        "WITH required_flows AS ( " +
        "  SELECT flow_name " +
        "  FROM recon_expected_flow " +
        "  WHERE required = true " +
        "    AND effective_from <= DATE '" + tradeDate + "' " +
        "    AND (effective_to IS NULL OR effective_to >= DATE '" + tradeDate + "') " +
        "), required_count AS ( " +
        "  SELECT COUNT(*) AS required_count FROM required_flows " +
        "), latest_per_flow AS ( " +
        "  SELECT * FROM ( " +
        "    SELECT e.trade_date, e.trade_id, e.version, e.flow_name, e.status, e.proc_ms, e.src_audit_id, " +
        "           ROW_NUMBER() OVER (PARTITION BY e.trade_date, e.trade_id, e.version, e.flow_name ORDER BY e.src_audit_id DESC) AS rn " +
        "    FROM recon_event e " +
        "    WHERE e.trade_date = DATE '" + tradeDate + "' " +
        "  ) t WHERE rn = 1 " +
        "), trade_rollup AS ( " +
        "  SELECT l.trade_date, l.trade_id, l.version, " +
        "         COUNT(*) FILTER (WHERE rf.flow_name IS NOT NULL AND l.status = 'SUCCESS') AS success_flows, " +
        "         SUM(COALESCE(l.proc_ms,0)) FILTER (WHERE l.status = 'SUCCESS') AS total_proc_ms, " +
        "         jsonb_object_agg(l.flow_name, COALESCE(l.proc_ms,0)) AS per_flow_proc_ms_json " +
        "  FROM latest_per_flow l " +
        "  LEFT JOIN required_flows rf ON l.flow_name = rf.flow_name " +
        "  GROUP BY l.trade_date, l.trade_id, l.version " +
        "), final_report AS ( " +
        "  SELECT t.trade_date, t.trade_id, t.version, " +
        "         CASE WHEN t.success_flows = r.required_count THEN 'MATCHED' ELSE 'UNMATCHED' END AS final_status, " +
        "         t.total_proc_ms, t.per_flow_proc_ms_json, " +
        "         ARRAY( " +
        "           SELECT rf.flow_name FROM required_flows rf " +
        "           LEFT JOIN latest_per_flow lf ON rf.flow_name = lf.flow_name AND lf.trade_id = t.trade_id AND lf.version = t.version " +
        "           WHERE lf.flow_name IS NULL OR lf.status <> 'SUCCESS' " +
        "         ) AS missing_required_flows " +
        "  FROM trade_rollup t CROSS JOIN required_count r " +
        ") " +
        "SELECT trade_date, trade_id, version, final_status, total_proc_ms, per_flow_proc_ms_json, missing_required_flows " +
        "FROM final_report " +
        filterUnmatched +
        " ORDER BY trade_id, version " +
        ") TO STDOUT WITH (FORMAT CSV, HEADER true, ENCODING 'UTF8')";
  }
}
