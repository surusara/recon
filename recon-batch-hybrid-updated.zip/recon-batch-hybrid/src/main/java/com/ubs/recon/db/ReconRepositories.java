package com.ubs.recon.db;

import lombok.AllArgsConstructor;
import lombok.Data;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.sql.ResultSet;
import java.time.OffsetDateTime;
import java.util.List;

@Repository
public class ReconRepositories {

  private final JdbcTemplate jdbc;

  public ReconRepositories(JdbcTemplate jdbc) {
    this.jdbc = jdbc;
  }

  @Data
  @AllArgsConstructor
  public static class SourceConfig {
    private String sourceName;
    private String dbHost;
    private Integer dbPort;
    private String dbName;
    private String jdbcParams;
    private String auditTable;
    private String incrementalSqlTemplate;
    private Integer batchSize;
    private boolean enabled;
  }

  public List<SourceConfig> loadEnabledSources() {
    return jdbc.query(
        "SELECT source_name, db_host, db_port, db_name, jdbc_params, audit_table, incremental_sql_template, batch_size, enabled " +
            "FROM recon_source_config WHERE enabled = true ORDER BY source_name",
        (rs, rowNum) -> mapSource(rs));
  }

  private SourceConfig mapSource(ResultSet rs) throws java.sql.SQLException {
    return new SourceConfig(
        rs.getString("source_name"),
        rs.getString("db_host"),
        rs.getInt("db_port"),
        rs.getString("db_name"),
        rs.getString("jdbc_params"),
        rs.getString("audit_table"),
        rs.getString("incremental_sql_template"),
        rs.getInt("batch_size"),
        rs.getBoolean("enabled"));
  }

  public long getLastSeenId(String sourceName) {
    Long v = jdbc.queryForObject(
        "SELECT last_seen_id FROM recon_checkpoint WHERE source_name = ?",
        Long.class, sourceName);
    return v == null ? 0L : v;
  }

  public void upsertCheckpoint(String sourceName, long lastSeenId) {
    jdbc.update(
        "INSERT INTO recon_checkpoint(source_name, last_seen_id, updated_at) VALUES(?,?,now()) " +
            "ON CONFLICT (source_name) DO UPDATE SET last_seen_id = EXCLUDED.last_seen_id, updated_at = now()",
        sourceName, lastSeenId);
  }

  public void ensurePartition(java.time.LocalDate tradeDate) {
    jdbc.update("SELECT ensure_recon_partition(?)", tradeDate);
  }

  public void insertReconEventsBatch(List<Object[]> batchArgs) {
    jdbc.batchUpdate(
        "INSERT INTO recon_event(trade_date, trade_id, version, flow_name, status, proc_ms, created_at, src_audit_id) " +
            "VALUES (?,?,?,?,?,?,?,?)",
        batchArgs);
  }

  public int dropPartitionsOlderThan(java.time.LocalDate cutoffDate) {
    Integer dropped = jdbc.queryForObject("SELECT drop_recon_partitions_older_than(?)", Integer.class, cutoffDate);
    return dropped == null ? 0 : dropped;
  }

  @Data
  @AllArgsConstructor
  public static class ExpectedFlow {
    private String flowName;
  }

  public List<String> requiredFlows(java.time.LocalDate tradeDate) {
    return jdbc.queryForList(
        "SELECT flow_name FROM recon_expected_flow " +
            "WHERE required = true AND effective_from <= ? AND (effective_to IS NULL OR effective_to >= ?)",
        String.class, tradeDate, tradeDate);
  }
}
