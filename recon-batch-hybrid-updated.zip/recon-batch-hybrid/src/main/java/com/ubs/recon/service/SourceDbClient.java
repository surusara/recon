package com.ubs.recon.service;

import lombok.extern.slf4j.Slf4j;

import java.sql.*;
import java.time.LocalDate;
import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.List;

@Slf4j
public class SourceDbClient {

  private final String jdbcUrl;
  private final String user;
  private final String password;

  public SourceDbClient(String jdbcUrl, String user, String password) {
    this.jdbcUrl = jdbcUrl;
    this.user = user;
    this.password = password;
  }

  public interface RowHandler {
    void handle(Row row) throws Exception;
  }

  public record Row(
      long srcAuditId,
      LocalDate tradeDate,
      String tradeId,
      int version,
      String flowName,
      String status,
      Long procMs,
      OffsetDateTime createdAt
  ) {}

  /**
   * Streams rows using server-side cursor (Postgres) when autoCommit=false and fetchSize>0.
   */
  public long streamIncremental(String sql, int fetchSize, RowHandler handler) throws Exception {
    long maxSeen = 0L;
    try (Connection conn = DriverManager.getConnection(jdbcUrl, user, password)) {
      conn.setAutoCommit(false);
      try (PreparedStatement ps = conn.prepareStatement(sql, ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_READ_ONLY)) {
        ps.setFetchSize(fetchSize);
        try (ResultSet rs = ps.executeQuery()) {
          while (rs.next()) {
            long id = rs.getLong("src_audit_id");
            maxSeen = Math.max(maxSeen, id);

            LocalDate tradeDate = rs.getObject("trade_date", LocalDate.class);
            String tradeId = rs.getString("trade_id");
            int version = rs.getInt("version");
            String flowName = rs.getString("flow_name");
            String status = rs.getString("status");
            Long procMs = (Long) rs.getObject("proc_ms");
            OffsetDateTime createdAt = rs.getObject("created_at", OffsetDateTime.class);

            handler.handle(new Row(id, tradeDate, tradeId, version, flowName, status, procMs, createdAt));
          }
        }
      }
      conn.commit();
    }
    return maxSeen;
  }
}
