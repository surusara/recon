package com.ubs.recon.batch;

import org.springframework.batch.core.scope.context.ChunkContext;

import java.time.LocalDate;

public final class BatchParams {
  private BatchParams() {}

  public static LocalDate requireBusinessDate(ChunkContext ctx) {
    Object v = ctx.getStepContext().getJobParameters().get("businessDate");
    if (v == null) {
      throw new IllegalArgumentException("Missing job parameter: businessDate (YYYY-MM-DD)");
    }
    return LocalDate.parse(v.toString());
  }
}
