package com.ubs.recon.poll;

import com.ubs.recon.db.SourceConfig;

import java.sql.Connection;
import java.sql.DriverManager;

public class SourceJdbcFactory {

  public static Connection open(SourceConfig cfg, String username, String password) throws Exception {
    String url = "jdbc:postgresql://%s:%d/%s".formatted(cfg.dbHost(), cfg.dbPort(), cfg.dbName());
    if (cfg.jdbcParams() != null && !cfg.jdbcParams().isBlank()) {
      url = url + "?" + cfg.jdbcParams();
    }
    return DriverManager.getConnection(url, username, password);
  }
}
