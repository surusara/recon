package com.ubs.recon.batch;

import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import java.time.LocalDate;

@Component
public class CleanupTasklet implements Tasklet {

  private final JdbcTemplate jdbc;
  private final int retentionDays;

  public CleanupTasklet(JdbcTemplate jdbc, @Value("${recon.retention-days:30}") int retentionDays) {
    this.jdbc = jdbc;
    this.retentionDays = retentionDays;
  }

  @Override
  public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) {

    // Drops partitions older than retentionDays via SQL helper function.
    LocalDate cutoff = LocalDate.now().minusDays(retentionDays);
    jdbc.update("SELECT drop_recon_partitions_older_than(?)", java.sql.Date.valueOf(cutoff));

    return RepeatStatus.FINISHED;
  }
}
