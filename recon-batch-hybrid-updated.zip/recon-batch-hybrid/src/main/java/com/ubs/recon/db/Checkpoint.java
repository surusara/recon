package com.ubs.recon.db;

public record Checkpoint(String sourceName, long lastSeenId) {}
