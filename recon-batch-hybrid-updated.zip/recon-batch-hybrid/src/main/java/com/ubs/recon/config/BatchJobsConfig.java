package com.ubs.recon.config;

import com.ubs.recon.batch.CleanupTasklet;
import com.ubs.recon.batch.EndOfDayReportTasklet;
import com.ubs.recon.batch.UnmatchedReportTasklet;
import com.ubs.recon.poll.PollingTasklet;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.job.builder.JobBuilder;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.batch.core.step.builder.StepBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.transaction.PlatformTransactionManager;

@Configuration
@EnableBatchProcessing
public class BatchJobsConfig {

  @Bean
  public Job pollInsertJob(JobRepository jobRepository, Step pollInsertStep) {
    return new JobBuilder("pollInsertJob", jobRepository)
        .incrementer(new RunIdIncrementer())
        .start(pollInsertStep)
        .build();
  }

  @Bean
  public Step pollInsertStep(JobRepository jobRepository,
                             PlatformTransactionManager transactionManager,
                             PollingTasklet tasklet) {
    return new StepBuilder("pollInsertStep", jobRepository)
        .tasklet(tasklet, transactionManager)
        .build();
  }

  @Bean
  public Job unmatchedReportJob(JobRepository jobRepository, Step unmatchedReportStep) {
    return new JobBuilder("unmatchedReportJob", jobRepository)
        .incrementer(new RunIdIncrementer())
        .start(unmatchedReportStep)
        .build();
  }

  @Bean
  public Step unmatchedReportStep(JobRepository jobRepository,
                                 PlatformTransactionManager transactionManager,
                                 UnmatchedReportTasklet tasklet) {
    return new StepBuilder("unmatchedReportStep", jobRepository)
        .tasklet(tasklet, transactionManager)
        .build();
  }

  @Bean
  public Job endOfDayReportJob(JobRepository jobRepository, Step endOfDayReportStep) {
    return new JobBuilder("endOfDayReportJob", jobRepository)
        .incrementer(new RunIdIncrementer())
        .start(endOfDayReportStep)
        .build();
  }

  @Bean
  public Step endOfDayReportStep(JobRepository jobRepository,
                                PlatformTransactionManager transactionManager,
                                EndOfDayReportTasklet tasklet) {
    return new StepBuilder("endOfDayReportStep", jobRepository)
        .tasklet(tasklet, transactionManager)
        .build();
  }

  @Bean
  public Job cleanupJob(JobRepository jobRepository, Step cleanupStep) {
    return new JobBuilder("cleanupJob", jobRepository)
        .incrementer(new RunIdIncrementer())
        .start(cleanupStep)
        .build();
  }

  @Bean
  public Step cleanupStep(JobRepository jobRepository,
                          PlatformTransactionManager transactionManager,
                          CleanupTasklet tasklet) {
    return new StepBuilder("cleanupStep", jobRepository)
        .tasklet(tasklet, transactionManager)
        .build();
  }
}
