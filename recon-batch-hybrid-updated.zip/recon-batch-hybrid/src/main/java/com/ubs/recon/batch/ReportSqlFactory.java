package com.ubs.recon.batch;

import java.time.LocalDate;

public class ReportSqlFactory {

  private static String baseSelect(LocalDate tradeDate) {
    // Latest-per-flow logic + required flows from config; JSON per flow processing time.
    return """
      COPY (
        WITH required_flows AS (
          SELECT flow_name
          FROM recon_expected_flow
          WHERE required = true
            AND effective_from <= DATE '%s'
            AND (effective_to IS NULL OR effective_to >= DATE '%s')
        ), required_count AS (
          SELECT COUNT(*) AS required_count FROM required_flows
        ), latest_per_flow AS (
          SELECT *
          FROM (
            SELECT
              e.trade_date,
              e.trade_id,
              e.version,
              e.flow_name,
              e.status,
              e.proc_ms,
              e.created_at,
              ROW_NUMBER() OVER (
                PARTITION BY e.trade_date, e.trade_id, e.version, e.flow_name
                ORDER BY e.src_audit_id DESC
              ) AS rn
            FROM recon_event e
            WHERE e.trade_date = DATE '%s'
          ) t
          WHERE rn = 1
        ), trade_rollup AS (
          SELECT
            l.trade_date,
            l.trade_id,
            l.version,
            COUNT(*) FILTER (WHERE rf.flow_name IS NOT NULL AND l.status='SUCCESS') AS success_flows,
            SUM(COALESCE(l.proc_ms,0)) FILTER (WHERE l.status='SUCCESS')            AS total_proc_ms,
            jsonb_object_agg(l.flow_name, COALESCE(l.proc_ms,0))                    AS per_flow_proc_ms_json
          FROM latest_per_flow l
          LEFT JOIN required_flows rf ON l.flow_name = rf.flow_name
          GROUP BY l.trade_date, l.trade_id, l.version
        )
        SELECT
          t.trade_date,
          t.trade_id,
          t.version,
          CASE WHEN t.success_flows = r.required_count THEN 'MATCHED' ELSE 'UNMATCHED' END AS final_status,
          t.total_proc_ms,
          t.per_flow_proc_ms_json,
          ARRAY(
            SELECT rf.flow_name
            FROM required_flows rf
            LEFT JOIN latest_per_flow lf
                   ON rf.flow_name = lf.flow_name
                  AND lf.trade_id = t.trade_id
                  AND lf.version  = t.version
            WHERE lf.flow_name IS NULL OR lf.status <> 'SUCCESS'
          ) AS missing_required_flows
        FROM trade_rollup t
        CROSS JOIN required_count r
      ) TO STDOUT WITH (FORMAT CSV, HEADER true, ENCODING 'UTF8')
      """.formatted(tradeDate, tradeDate, tradeDate);
  }

  public static String endOfDay(LocalDate tradeDate) {
    return baseSelect(tradeDate);
  }

  public static String unmatchedOnly(LocalDate tradeDate) {
    // Wrap base query with filter by final_status.
    // For COPY, easiest: add WHERE at outermost select.
    return """
      COPY (
        WITH required_flows AS (
          SELECT flow_name
          FROM recon_expected_flow
          WHERE required = true
            AND effective_from <= DATE '%s'
            AND (effective_to IS NULL OR effective_to >= DATE '%s')
        ), required_count AS (
          SELECT COUNT(*) AS required_count FROM required_flows
        ), latest_per_flow AS (
          SELECT *
          FROM (
            SELECT
              e.trade_date,
              e.trade_id,
              e.version,
              e.flow_name,
              e.status,
              e.proc_ms,
              e.created_at,
              ROW_NUMBER() OVER (
                PARTITION BY e.trade_date, e.trade_id, e.version, e.flow_name
                ORDER BY e.src_audit_id DESC
              ) AS rn
            FROM recon_event e
            WHERE e.trade_date = DATE '%s'
          ) t
          WHERE rn = 1
        ), trade_rollup AS (
          SELECT
            l.trade_date,
            l.trade_id,
            l.version,
            COUNT(*) FILTER (WHERE rf.flow_name IS NOT NULL AND l.status='SUCCESS') AS success_flows,
            SUM(COALESCE(l.proc_ms,0)) FILTER (WHERE l.status='SUCCESS')            AS total_proc_ms,
            jsonb_object_agg(l.flow_name, COALESCE(l.proc_ms,0))                    AS per_flow_proc_ms_json
          FROM latest_per_flow l
          LEFT JOIN required_flows rf ON l.flow_name = rf.flow_name
          GROUP BY l.trade_date, l.trade_id, l.version
        )
        SELECT
          t.trade_date,
          t.trade_id,
          t.version,
          'UNMATCHED' AS final_status,
          t.total_proc_ms,
          t.per_flow_proc_ms_json,
          ARRAY(
            SELECT rf.flow_name
            FROM required_flows rf
            LEFT JOIN latest_per_flow lf
                   ON rf.flow_name = lf.flow_name
                  AND lf.trade_id = t.trade_id
                  AND lf.version  = t.version
            WHERE lf.flow_name IS NULL OR lf.status <> 'SUCCESS'
          ) AS missing_required_flows
        FROM trade_rollup t
        CROSS JOIN required_count r
        WHERE t.success_flows <> r.required_count
      ) TO STDOUT WITH (FORMAT CSV, HEADER true, ENCODING 'UTF8')
      """.formatted(tradeDate, tradeDate, tradeDate);
  }
}
