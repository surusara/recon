package com.ubs.recon.runner;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.BatchStatus;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Optional;

/**
 * Enforces "exactly one Spring Batch job per pod".
 *
 * Why this exists:
 *  - In Kubernetes Job mode, Autosys expects a process exit code (0=success, non-zero=failure).
 *  - Spring Boot's default JobLauncherApplicationRunner may run multiple jobs if spring.batch.job.name is missing.
 *
 * Contract:
 *  - REQUIRED: --spring.batch.job.name=<jobBeanName>
 *  - REQUIRED: businessDate=YYYY-MM-DD (JobParameter)
 *
 * Exit codes:
 *  - 0 : Job COMPLETED
 *  - 1 : Job FAILED/STOPPED/UNKNOWN
 *  - 2 : Invalid input (missing job name / missing businessDate / unknown job)
 */
@Component
public class MandatorySingleJobRunner implements ApplicationRunner {

  private static final Logger log = LoggerFactory.getLogger(MandatorySingleJobRunner.class);

  private final ConfigurableApplicationContext ctx;
  private final Environment env;
  private final JobLauncher jobLauncher;

  public MandatorySingleJobRunner(
      ConfigurableApplicationContext ctx,
      Environment env,
      JobLauncher jobLauncher
  ) {
    this.ctx = ctx;
    this.env = env;
    this.jobLauncher = jobLauncher;
  }

  @Override
  public void run(ApplicationArguments args) {
    int exitCode;
    try {
      String jobName = Optional.ofNullable(env.getProperty("spring.batch.job.name"))
          .map(String::trim)
          .filter(s -> !s.isEmpty())
          .orElseThrow(() -> new IllegalArgumentException(
              "Missing required parameter: --spring.batch.job.name=<jobName>"));

      String businessDate = resolveBusinessDate(args)
          .orElseThrow(() -> new IllegalArgumentException(
              "Missing required JobParameter: businessDate=YYYY-MM-DD"));

      Job job = ctx.getBean(jobName, Job.class);

      JobParameters params = new JobParametersBuilder()
          .addString("businessDate", businessDate)
          // Unique run id so re-runs don't collide in Spring Batch metadata.
          .addLong("run.id", System.currentTimeMillis())
          .toJobParameters();

      log.info("Launching Spring Batch job='{}' with businessDate='{}'", jobName, businessDate);
      JobExecution execution = jobLauncher.run(job, params);

      exitCode = (execution.getStatus() == BatchStatus.COMPLETED) ? 0 : 1;
      log.info("Job '{}' finished with status={} -> exitCode={}", jobName, execution.getStatus(), exitCode);

    } catch (IllegalArgumentException e) {
      log.error("Invalid invocation: {}", e.getMessage());
      exitCode = 2;
    } catch (Exception e) {
      log.error("Job execution failed", e);
      exitCode = 1;
    }

    // Ensure the pod terminates and Autosys gets a deterministic exit code.
    int finalExit = SpringApplication.exit(ctx, () -> exitCode);
    System.exit(finalExit);
  }

  private Optional<String> resolveBusinessDate(ApplicationArguments args) {
    // Preferred: JobParameter style: businessDate=YYYY-MM-DD (non-option arg)
    List<String> nonOptionArgs = args.getNonOptionArgs();
    for (String s : nonOptionArgs) {
      if (s != null && s.startsWith("businessDate=")) {
        String v = s.substring("businessDate=".length()).trim();
        if (!v.isEmpty()) return Optional.of(v);
      }
    }

    // Also allow: --businessDate=YYYY-MM-DD
    if (args.containsOption("businessDate")) {
      List<String> vals = args.getOptionValues("businessDate");
      if (vals != null && !vals.isEmpty() && vals.get(0) != null && !vals.get(0).isBlank()) {
        return Optional.of(vals.get(0).trim());
      }
    }

    // Fallback: environment property (less preferred)
    String envVal = env.getProperty("businessDate");
    if (envVal != null && !envVal.isBlank()) {
      return Optional.of(envVal.trim());
    }

    return Optional.empty();
  }
}
