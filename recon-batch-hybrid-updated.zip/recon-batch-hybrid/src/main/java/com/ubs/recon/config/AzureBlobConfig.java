package com.ubs.recon.config;

import com.azure.storage.blob.BlobContainerClient;
import com.azure.storage.blob.BlobServiceClient;
import com.azure.storage.blob.BlobServiceClientBuilder;
import com.azure.storage.blob.specialized.BlockBlobClient;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class AzureBlobConfig {

  @Bean
  public BlobServiceClient blobServiceClient(@Value("${azure.blob.connectionString}") String connStr) {
    return new BlobServiceClientBuilder().connectionString(connStr).buildClient();
  }

  @Bean
  public BlobContainerClient blobContainerClient(
      BlobServiceClient client,
      @Value("${azure.blob.container}") String container) {
    BlobContainerClient c = client.getBlobContainerClient(container);
    if (!c.exists()) {
      c.create();
    }
    return c;
  }

  public static BlockBlobClient blockBlob(BlobContainerClient container, String blobPath) {
    return container.getBlobClient(blobPath).getBlockBlobClient();
  }
}
