# recon-batch-hybrid (Java 21, Spring Batch, Postgres, Azure Blob)

This project implements the **hybrid recon strategy** discussed:

- **Job 1 (pollJob)**: cursor-based polling from multiple microservice Postgres DBs (incremental) and append-only insert into central `recon_event`.
- **Job 2 (unmatchedReportJob)**: generate **UNMATCHED** CSV and stream directly to **Azure Blob** using **Postgres COPY TO STDOUT**.
- **Job 3 (endOfDayReportJob)**: generate **EOD** CSV and stream directly to **Azure Blob** using **Postgres COPY TO STDOUT**.
- **Job 4 (cleanupJob)**: drop old daily partitions (retention).

Designed for **AKS Kubernetes Job** triggered by **Autosys**. No Helm included.

---

## Build

```bash
mvn -q -DskipTests package
```

Run locally:

```bash
export RECON_DB_URL='jdbc:postgresql://localhost:5432/recon'
export RECON_DB_USER='recon_user'
export RECON_DB_PASSWORD='recon_pass'
export AZURE_BLOB_CONNECTION_STRING='...'
export AZURE_BLOB_CONTAINER='recon-reports'

# Run a job by name with businessDate
java -jar target/recon-batch-hybrid-0.1.0.jar --spring.batch.job.name=pollJob businessDate=2026-01-22
java -jar target/recon-batch-hybrid-0.1.0.jar --spring.batch.job.name=unmatchedReportJob businessDate=2026-01-22
java -jar target/recon-batch-hybrid-0.1.0.jar --spring.batch.job.name=endOfDayReportJob businessDate=2026-01-22
java -jar target/recon-batch-hybrid-0.1.0.jar --spring.batch.job.name=cleanupJob businessDate=2026-01-22
```

### Mandatory job selection + exit codes (for Autosys)

This application is intended to run as a **Kubernetes Job (one pod per run)**.

**You MUST pass** `--spring.batch.job.name=<jobBeanName>` so only one job runs.

The process terminates after the selected job finishes (important for Autosys):

- Exit **0**: Spring Batch Job status `COMPLETED`
- Exit **1**: Job status `FAILED/STOPPED/UNKNOWN` or unexpected exception
- Exit **2**: Invalid invocation (missing job name, missing businessDate, unknown job bean)

---

## Central DB schema

Flyway migration: `src/main/resources/db/migration/V1__recon_schema.sql`

Key tables:
- `recon_event` (partitioned by `trade_date`)
- `recon_source_config` (config-driven onboarding)
- `recon_checkpoint` (last_seen_id per source)
- `recon_expected_flow` (required flows; supports 13 -> 14 with no code change)

---

## Source onboarding (config-driven)

Insert one row into `recon_source_config` for each microservice DB.

### Incremental SQL template

The template must return these **column aliases**:

- `src_audit_id` (monotonic increasing ID from source audit table)
- `trade_date` (DATE)
- `trade_id` (TEXT)
- `version` (INT)
- `flow_name` (TEXT)
- `status` (TEXT)
- `proc_ms` (BIGINT, nullable)
- `created_at` (TIMESTAMPTZ)

Allowed placeholders:
- `${last_seen_id}`
- `${business_date}`
- `${limit}`

Example:

```sql
SELECT
  id            AS src_audit_id,
  trade_date    AS trade_date,
  event_id      AS trade_id,
  event_version AS version,
  'trade_ingestion'::text AS flow_name,
  status        AS status,
  proc_ms       AS proc_ms,
  created_at    AS created_at
FROM trade_ingestion_audit
WHERE id > ${last_seen_id}
  AND trade_date = DATE '${business_date}'
ORDER BY id
LIMIT ${limit}
```

---

## Blob paths

Configured prefix: `RECON_BLOB_PREFIX` (default `recon`)

- Unmatched: `recon/unmatched/<businessDate>/unmatched.csv`
- EOD: `recon/eod/<businessDate>/eod.csv`

CSV columns:
- trade_date
- trade_id
- version
- final_status
- total_proc_ms
- per_flow_proc_ms_json
- missing_required_flows

---

## Notes / extensions

- **Retry handling**: reporting SQL uses `latest_per_flow` (row_number over src_audit_id desc) so FAIL then SUCCESS is treated correctly.
- **Fan-out (trade -> SO -> funding/accounting)**: current report SQL assumes recon_event already maps flows to `trade_id`. To support SO-level completeness, extend recon_event to store `entity_type/entity_id` and aggregate child entities to trade-level in the COPY SQL.
- For heavier workloads, consider running export steps against a read replica.

---

## AKS Job usage (Autosys)

Autosys triggers a Kubernetes Job that runs the same image with args:

```
--spring.batch.job.name=endOfDayReportJob businessDate=2026-01-22
```

Each run is isolated (new pod), and exits success/fail.
