-- Recon facts table (append-only) partitioned by trade_date
CREATE TABLE IF NOT EXISTS recon_event (
  trade_date   date        NOT NULL,
  trade_id     text        NOT NULL,
  version      int         NOT NULL,
  flow_name    text        NOT NULL,
  status       text        NOT NULL,
  proc_ms      bigint      NULL,
  created_at   timestamptz NOT NULL DEFAULT now(),
  src_audit_id bigint      NOT NULL
) PARTITION BY RANGE (trade_date);

-- Ensure base indexes exist at parent level (PG11+ propagates to partitions)
CREATE INDEX IF NOT EXISTS ix_recon_event_day_trade ON recon_event (trade_date, trade_id, version);
CREATE INDEX IF NOT EXISTS ix_recon_event_day_flow  ON recon_event (trade_date, flow_name);

-- Config: sources
CREATE TABLE IF NOT EXISTS recon_source_config (
  source_name          text PRIMARY KEY,
  db_host              text NOT NULL,
  db_port              int  NOT NULL DEFAULT 5432,
  db_name              text NOT NULL,
  jdbc_params          text NULL,
  audit_query_template text NOT NULL,
  fetch_size           int  NOT NULL DEFAULT 5000,
  batch_size           int  NOT NULL DEFAULT 50000,
  enabled              boolean NOT NULL DEFAULT true
);

-- Checkpoints (incremental polling)
CREATE TABLE IF NOT EXISTS recon_checkpoint (
  source_name  text PRIMARY KEY,
  last_seen_id bigint NOT NULL,
  updated_at   timestamptz NOT NULL DEFAULT now()
);

-- Expected flows (config-driven required flow list)
CREATE TABLE IF NOT EXISTS recon_expected_flow (
  flow_name      text NOT NULL,
  required       boolean NOT NULL DEFAULT true,
  effective_from date NOT NULL DEFAULT CURRENT_DATE,
  effective_to   date NULL,
  PRIMARY KEY(flow_name, effective_from)
);

-- Function: create daily partition on demand
CREATE OR REPLACE FUNCTION ensure_recon_partition(p_trade_date date)
RETURNS void
LANGUAGE plpgsql
AS $$
DECLARE
  part_name text;
  start_date date;
  end_date date;
BEGIN
  start_date := p_trade_date;
  end_date := p_trade_date + INTERVAL '1 day';
  part_name := format('recon_event_%s', to_char(start_date, 'YYYY_MM_DD'));

  IF NOT EXISTS (
    SELECT 1 FROM pg_class c
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE c.relkind = 'r'
      AND c.relname = part_name
  ) THEN
    EXECUTE format(
      'CREATE TABLE %I PARTITION OF recon_event FOR VALUES FROM (%L) TO (%L)',
      part_name, start_date, end_date
    );

    EXECUTE format('CREATE INDEX IF NOT EXISTS %I ON %I (trade_date, trade_id, version)',
      'ix_'||part_name||'_trade', part_name);

    EXECUTE format('CREATE INDEX IF NOT EXISTS %I ON %I (trade_date, flow_name)',
      'ix_'||part_name||'_flow', part_name);
  END IF;
END;
$$;

-- Function: drop partitions older than cutoff date
CREATE OR REPLACE FUNCTION drop_recon_partitions_older_than(p_cutoff date)
RETURNS void
LANGUAGE plpgsql
AS $$
DECLARE
  r record;
  part_date date;
BEGIN
  FOR r IN
    SELECT c.relname AS part_name
    FROM pg_inherits i
    JOIN pg_class c ON c.oid = i.inhrelid
    JOIN pg_class p ON p.oid = i.inhparent
    WHERE p.relname = 'recon_event'
  LOOP
    -- Partition names follow recon_event_YYYY_MM_DD
    BEGIN
      part_date := to_date(replace(r.part_name, 'recon_event_', ''), 'YYYY_MM_DD');
      IF part_date < p_cutoff THEN
        EXECUTE format('DROP TABLE IF EXISTS %I', r.part_name);
      END IF;
    EXCEPTION WHEN others THEN
      -- ignore partitions not matching naming convention
      CONTINUE;
    END;
  END LOOP;
END;
$$;
