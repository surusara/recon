package com.ubs.recon.batch;

import com.ubs.recon.export.PgCopyToBlobExporter;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.time.LocalDate;

@Component
public class EndOfDayReportTasklet implements Tasklet {

  private final PgCopyToBlobExporter exporter;
  private final String blobPrefix;

  public EndOfDayReportTasklet(PgCopyToBlobExporter exporter,
                              @Value("${reports.blob-prefix}") String blobPrefix) {
    this.exporter = exporter;
    this.blobPrefix = blobPrefix;
  }

  @Override
  public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {
    String businessDateStr = (String) chunkContext.getStepContext().getJobParameters().get("businessDate");
    if (businessDateStr == null || businessDateStr.isBlank()) {
      throw new IllegalArgumentException("Missing job parameter: businessDate=YYYY-MM-DD");
    }
    LocalDate date = LocalDate.parse(businessDateStr);

    String blobName = "%s/eod/%s_eod.csv".formatted(blobPrefix, date);
    String copySql = ReportSqlFactory.endOfDay(date);

    exporter.exportCsv(date, blobName, copySql);
    return RepeatStatus.FINISHED;
  }
}
