package com.ubs.recon.poll;

import java.time.Instant;
import java.time.LocalDate;

public record ReconEventRow(
    LocalDate tradeDate,
    String tradeId,
    int version,
    String flowName,
    String status,
    Long procMs,
    Instant createdAt,
    long srcAuditId
) {}
