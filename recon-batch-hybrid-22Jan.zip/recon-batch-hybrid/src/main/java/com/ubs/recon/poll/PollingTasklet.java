package com.ubs.recon.poll;

import com.ubs.recon.db.ReconRepositories;
import com.ubs.recon.db.SourceConfig;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.time.Instant;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

/**
 * Job 1: Poll sources (cursor-based fetch) and insert append-only rows into recon_event.
 *
 * The source SQL is config-driven (audit_query_template) and must return the standard columns:
 *   src_audit_id (bigint), trade_date (date), trade_id (text), version (int), status (text), proc_ms (bigint), created_at (timestamptz)
 * flow_name is provided by config/source_name.
 */
@Component
public class PollingTasklet implements Tasklet {

  private final ReconRepositories repos;
  private final JdbcTemplate reconJdbc;
  private final List<SourceConfig> sources;

  private final String sharedSourceUsername;
  private final String sharedSourcePassword;

  public PollingTasklet(
      ReconRepositories repos,
      JdbcTemplate reconJdbc,
      @Value("${sources.shared.username}") String sharedSourceUsername,
      @Value("${sources.shared.password}") String sharedSourcePassword) {
    this.repos = repos;
    this.reconJdbc = reconJdbc;
    this.sharedSourceUsername = sharedSourceUsername;
    this.sharedSourcePassword = sharedSourcePassword;
    this.sources = repos.loadEnabledSources();
  }

  @Override
  public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {

    String businessDateStr = (String) chunkContext.getStepContext().getJobParameters().get("businessDate");
    if (businessDateStr == null || businessDateStr.isBlank()) {
      throw new IllegalArgumentException("Missing job parameter: businessDate=YYYY-MM-DD");
    }
    LocalDate businessDate = LocalDate.parse(businessDateStr);

    // Ensure partition exists for the business date (trade_date).
    repos.ensurePartition(businessDate);

    for (SourceConfig cfg : sources) {
      pollOneSource(cfg, businessDate);
    }

    return RepeatStatus.FINISHED;
  }

  private void pollOneSource(SourceConfig cfg, LocalDate businessDate) throws Exception {

    long lastSeenId = repos.loadCheckpoint(cfg.sourceName()).map(c -> c.lastSeenId()).orElse(0L);

    // Template substitution (guardrail: only numbers/date are substituted, not user input)
    String sql = cfg.auditQueryTemplate()
        .replace("${last_seen_id}", Long.toString(lastSeenId))
        .replace("${business_date}", businessDate.toString())
        .replace("${limit}", Integer.toString(cfg.batchSize()));

    long maxSeen = lastSeenId;

    try (Connection conn = SourceJdbcFactory.open(cfg, sharedSourceUsername, sharedSourcePassword)) {
      conn.setAutoCommit(false);
      try (PreparedStatement ps = conn.prepareStatement(sql, ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_READ_ONLY)) {
        ps.setFetchSize(cfg.fetchSize());

        try (ResultSet rs = ps.executeQuery()) {

          List<Object[]> batch = new ArrayList<>(cfg.batchSize());

          while (rs.next()) {
            long srcAuditId = rs.getLong("src_audit_id");
            maxSeen = Math.max(maxSeen, srcAuditId);

            LocalDate tradeDate = rs.getDate("trade_date").toLocalDate();
            String tradeId = rs.getString("trade_id");
            int version = rs.getInt("version");
            String status = rs.getString("status");
            Long procMs = rs.getObject("proc_ms") == null ? null : rs.getLong("proc_ms");
            Instant createdAt = rs.getTimestamp("created_at").toInstant();

            // Insert row values; flow_name uses cfg.sourceName() to keep it stable.
            batch.add(new Object[]{
                java.sql.Date.valueOf(tradeDate),
                tradeId,
                version,
                cfg.sourceName(),
                status,
                procMs,
                java.sql.Timestamp.from(createdAt),
                srcAuditId
            });

            if (batch.size() >= 10_000) {
              insertBatch(batch);
              batch.clear();
            }
          }

          if (!batch.isEmpty()) {
            insertBatch(batch);
            batch.clear();
          }
        }
      }
      conn.commit();
    }

    if (maxSeen > lastSeenId) {
      repos.upsertCheckpoint(cfg.sourceName(), maxSeen);
    }
  }

  private void insertBatch(List<Object[]> batch) {
    reconJdbc.batchUpdate(
        """
        INSERT INTO recon_event(
          trade_date, trade_id, version, flow_name, status, proc_ms, created_at, src_audit_id
        ) VALUES (?,?,?,?,?,?,?,?)
        """,
        batch
    );
  }
}
