package com.ubs.recon.export;

import com.azure.storage.blob.BlobContainerClient;
import com.azure.storage.blob.specialized.BlockBlobClient;
import com.azure.storage.blob.specialized.BlobOutputStream;
import org.postgresql.PGConnection;
import org.postgresql.copy.CopyManager;
import org.springframework.stereotype.Component;

import javax.sql.DataSource;
import java.sql.Connection;
import java.time.LocalDate;

/**
 * Streams Postgres COPY output directly to Azure Blob Storage.
 * This is best for huge CSV exports: minimal JVM memory and minimal pod CPU (just piping bytes).
 */
@Component
public class PgCopyToBlobExporter {

  private final DataSource reconDataSource;
  private final BlobContainerClient container;

  public PgCopyToBlobExporter(DataSource reconDataSource, BlobContainerClient container) {
    this.reconDataSource = reconDataSource;
    this.container = container;
  }

  public void exportCsv(LocalDate tradeDate, String blobName, String copySql) throws Exception {

    BlockBlobClient blobClient = container.getBlobClient(blobName).getBlockBlobClient();

    try (Connection conn = reconDataSource.getConnection()) {
      conn.setAutoCommit(false);
      PGConnection pg = conn.unwrap(PGConnection.class);
      CopyManager cm = pg.getCopyAPI();

      try (BlobOutputStream out = blobClient.getBlobOutputStream(true)) {
        cm.copyOut(copySql, out);
        out.flush();
      }

      conn.commit();
    }
  }
}
