package com.ubs.recon.service;

import java.time.LocalDate;

/**
 * Minimal and safe-ish template expansion for configured incremental SQL.
 *
 * Allowed placeholders:
 *  - ${last_seen_id} (long)
 *  - ${business_date} (YYYY-MM-DD)
 *  - ${limit} (int)
 *
 * Note: Keep configured SQL as SELECT-only.
 */
public final class SqlTemplate {
  private SqlTemplate() {}

  public static String expand(String template, long lastSeenId, LocalDate businessDate, int limit) {
    String sql = template;
    sql = sql.replace("${last_seen_id}", Long.toString(lastSeenId));
    sql = sql.replace("${business_date}", businessDate.toString());
    sql = sql.replace("${limit}", Integer.toString(limit));
    return sql;
  }
}
