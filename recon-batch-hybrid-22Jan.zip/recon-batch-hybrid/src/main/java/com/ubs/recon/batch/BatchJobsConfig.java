package com.ubs.recon.batch;

import com.ubs.recon.service.PgCopyToBlobExporter;
import com.ubs.recon.service.ReconPollService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.job.builder.JobBuilder;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.batch.core.step.builder.StepBuilder;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.transaction.PlatformTransactionManager;

import java.time.LocalDate;

@Slf4j
@Configuration
@EnableBatchProcessing
public class BatchJobsConfig {

  @Value("${recon.report.blobPrefix:recon}")
  private String blobPrefix;

  @Value("${recon.retention.days:30}")
  private int retentionDays;

  @Bean
  public Job pollJob(JobRepository jobRepository, Step pollStep) {
    return new JobBuilder("pollJob", jobRepository)
        .incrementer(new RunIdIncrementer())
        .start(pollStep)
        .build();
  }

  @Bean
  public Step pollStep(JobRepository jobRepository,
                      PlatformTransactionManager transactionManager,
                      ReconPollService pollService) {
    return new StepBuilder("pollStep", jobRepository)
        .tasklet((contribution, chunkContext) -> {
          LocalDate businessDate = BatchParams.requireBusinessDate(chunkContext);
          log.info("Running pollStep businessDate={}", businessDate);
          pollService.pollAllSources(businessDate);
          return RepeatStatus.FINISHED;
        }, transactionManager)
        .build();
  }

  @Bean
  public Job unmatchedReportJob(JobRepository jobRepository, Step unmatchedReportStep) {
    return new JobBuilder("unmatchedReportJob", jobRepository)
        .incrementer(new RunIdIncrementer())
        .start(unmatchedReportStep)
        .build();
  }

  @Bean
  public Step unmatchedReportStep(JobRepository jobRepository,
                                 PlatformTransactionManager transactionManager,
                                 PgCopyToBlobExporter exporter) {
    return new StepBuilder("unmatchedReportStep", jobRepository)
        .tasklet((contribution, chunkContext) -> {
          LocalDate businessDate = BatchParams.requireBusinessDate(chunkContext);
          String blobPath = blobPrefix + "/unmatched/" + businessDate + "/unmatched.csv";
          log.info("Exporting UNMATCHED report to blobPath={}", blobPath);
          exporter.exportUnmatched(businessDate, blobPath);
          return RepeatStatus.FINISHED;
        }, transactionManager)
        .build();
  }

  @Bean
  public Job endOfDayReportJob(JobRepository jobRepository, Step endOfDayReportStep) {
    return new JobBuilder("endOfDayReportJob", jobRepository)
        .incrementer(new RunIdIncrementer())
        .start(endOfDayReportStep)
        .build();
  }

  @Bean
  public Step endOfDayReportStep(JobRepository jobRepository,
                                PlatformTransactionManager transactionManager,
                                PgCopyToBlobExporter exporter) {
    return new StepBuilder("endOfDayReportStep", jobRepository)
        .tasklet((contribution, chunkContext) -> {
          LocalDate businessDate = BatchParams.requireBusinessDate(chunkContext);
          String blobPath = blobPrefix + "/eod/" + businessDate + "/eod.csv";
          log.info("Exporting EOD report to blobPath={}", blobPath);
          exporter.exportEndOfDay(businessDate, blobPath);
          return RepeatStatus.FINISHED;
        }, transactionManager)
        .build();
  }

  @Bean
  public Job cleanupJob(JobRepository jobRepository, Step cleanupStep) {
    return new JobBuilder("cleanupJob", jobRepository)
        .incrementer(new RunIdIncrementer())
        .start(cleanupStep)
        .build();
  }

  @Bean
  public Step cleanupStep(JobRepository jobRepository,
                         PlatformTransactionManager transactionManager,
                         com.ubs.recon.db.ReconRepositories repo) {
    return new StepBuilder("cleanupStep", jobRepository)
        .tasklet((contribution, chunkContext) -> {
          LocalDate businessDate = BatchParams.requireBusinessDate(chunkContext);
          LocalDate cutoff = businessDate.minusDays(retentionDays);
          int dropped = repo.dropPartitionsOlderThan(cutoff);
          log.info("Cleanup: dropped {} partitions older than {}", dropped, cutoff);
          return RepeatStatus.FINISHED;
        }, transactionManager)
        .build();
  }
}
