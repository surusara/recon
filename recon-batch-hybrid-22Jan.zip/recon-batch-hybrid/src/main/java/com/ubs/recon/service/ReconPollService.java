package com.ubs.recon.service;

import com.ubs.recon.db.ReconRepositories;
import com.ubs.recon.db.ReconRepositories.SourceConfig;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

@Slf4j
@Service
@RequiredArgsConstructor
public class ReconPollService {

  private final ReconRepositories repo;

  @Value("${sources.shared.username}")
  private String sharedUser;

  @Value("${sources.shared.password}")
  private String sharedPassword;

  @Value("${sources.fetchSize:5000}")
  private int fetchSize;

  @Value("${recon.insert.batchSize:1000}")
  private int insertBatchSize;

  public void pollAllSources(LocalDate businessDate) throws Exception {
    List<SourceConfig> sources = repo.loadEnabledSources();
    if (sources.isEmpty()) {
      log.warn("No enabled sources in recon_source_config.");
      return;
    }

    // Ensure partition for this report date. If you store trade_date from source, you may need multiple dates.
    // For migration proving, businessDate partition is usually enough.
    repo.ensurePartition(businessDate);

    for (SourceConfig s : sources) {
      pollOneSource(businessDate, s);
    }
  }

  private void pollOneSource(LocalDate businessDate, SourceConfig s) throws Exception {
    long lastSeenId = repo.getLastSeenId(s.getSourceName());
    int limit = Math.max(1, s.getBatchSize());

    String sql = SqlTemplate.expand(s.getIncrementalSqlTemplate(), lastSeenId, businessDate, limit);

    String jdbcParams = (s.getJdbcParams() == null || s.getJdbcParams().isBlank()) ? "" : s.getJdbcParams();
    String jdbcUrl = "jdbc:postgresql://" + s.getDbHost() + ":" + s.getDbPort() + "/" + s.getDbName() + jdbcParams;

    log.info("Polling source={} lastSeenId={} businessDate={} limit={} jdbcUrl={}",
        s.getSourceName(), lastSeenId, businessDate, limit, redactJdbc(jdbcUrl));

    SourceDbClient client = new SourceDbClient(jdbcUrl, sharedUser, sharedPassword);

    List<Object[]> batch = new ArrayList<>(insertBatchSize);

    long maxSeen = client.streamIncremental(sql, fetchSize, row -> {
      // Insert into central recon_event
      batch.add(new Object[]{
          row.tradeDate(),
          row.tradeId(),
          row.version(),
          row.flowName(),
          row.status(),
          row.procMs(),
          row.createdAt(),
          row.srcAuditId()
      });

      if (batch.size() >= insertBatchSize) {
        repo.insertReconEventsBatch(batch);
        batch.clear();
      }
    });

    if (!batch.isEmpty()) {
      repo.insertReconEventsBatch(batch);
      batch.clear();
    }

    if (maxSeen > lastSeenId) {
      repo.upsertCheckpoint(s.getSourceName(), maxSeen);
      log.info("Updated checkpoint source={} lastSeenId={}", s.getSourceName(), maxSeen);
    } else {
      log.info("No new rows for source={}", s.getSourceName());
    }
  }

  private String redactJdbc(String jdbcUrl) {
    return jdbcUrl;
  }
}
