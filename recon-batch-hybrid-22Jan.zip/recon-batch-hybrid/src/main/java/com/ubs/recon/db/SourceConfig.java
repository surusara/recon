package com.ubs.recon.db;

public record SourceConfig(
    String sourceName,
    String dbHost,
    int dbPort,
    String dbName,
    String jdbcParams,
    String auditQueryTemplate,
    int fetchSize,
    int batchSize,
    boolean enabled
) {}
