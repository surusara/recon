package com.ubs.recon.repo;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.time.OffsetDateTime;

@Repository
public class CheckpointRepository {

  private final JdbcTemplate jdbc;

  public CheckpointRepository(JdbcTemplate jdbc) {
    this.jdbc = jdbc;
  }

  public long getLastSeenId(String sourceName) {
    String sql = "SELECT last_seen_id FROM recon_checkpoint WHERE source_name = ?";
    Long val = jdbc.query(sql, ps -> ps.setString(1, sourceName), rs -> rs.next() ? rs.getLong(1) : null);
    return val == null ? 0L : val;
  }

  public void upsertLastSeenId(String sourceName, long lastSeenId) {
    String sql = "INSERT INTO recon_checkpoint(source_name, last_seen_id, updated_at) VALUES(?,?,?) " +
        "ON CONFLICT (source_name) DO UPDATE SET last_seen_id = EXCLUDED.last_seen_id, updated_at = EXCLUDED.updated_at";
    jdbc.update(sql, sourceName, lastSeenId, OffsetDateTime.now());
  }
}
