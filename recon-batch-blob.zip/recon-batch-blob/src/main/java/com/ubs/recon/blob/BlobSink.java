package com.ubs.recon.blob;

import java.io.OutputStream;

/**
 * Abstraction to stream report output to storage.
 * In Azure deployment, implementation writes to Azure Blob Storage.
 */
public interface BlobSink {
  OutputStream open(String blobName) throws Exception;
}
