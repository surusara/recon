package com.ubs.recon.service;

import com.ubs.recon.ReconProperties;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.time.LocalDate;

@Component
public class Schedulers {

  private static final Logger log = LoggerFactory.getLogger(Schedulers.class);

  private final ReconProperties props;
  private final SourcePollingService poller;
  private final ReportService reports;

  public Schedulers(ReconProperties props, SourcePollingService poller, ReportService reports) {
    this.props = props;
    this.poller = poller;
    this.reports = reports;
  }

  // 10-minute polling (fixed delay)
  @Scheduled(fixedDelayString = "${recon.poll.fixed-delay-ms}")
  public void poll() {
    if (!props.poll().enabled()) return;
    log.info("Starting 10-min poll...");
    poller.pollAllSources(props.poll().perSourceLimit(), props.poll().maxSourcesParallel());
  }

  // Unmatched report every 2 hours
  @Scheduled(cron = "${recon.reports.unmatched-cron}")
  public void unmatchedReport() {
    if (!props.reports().enabled()) return;
    LocalDate tradeDate = LocalDate.now();
    log.info("Generating unmatched report for tradeDate={}", tradeDate);
    reports.exportUnmatched(tradeDate);
  }

  // End-of-day full report
  @Scheduled(cron = "${recon.reports.eod-cron}")
  public void eodReport() {
    if (!props.reports().enabled()) return;
    LocalDate tradeDate = LocalDate.now();
    log.info("Generating end-of-day report for tradeDate={}", tradeDate);
    reports.exportEndOfDay(tradeDate);
  }
}
