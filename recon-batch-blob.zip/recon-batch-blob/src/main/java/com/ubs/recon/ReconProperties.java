package com.ubs.recon;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.validation.annotation.Validated;

@Validated
@ConfigurationProperties(prefix = "recon")
public record ReconProperties(
    Poll poll,
    Reports reports,
    Azure azure
) {

  public record Poll(
      boolean enabled,
      long fixedDelayMs,
      @Min(100) int perSourceLimit,
      @Min(1) int maxSourcesParallel
  ) {}

  public record Reports(
      boolean enabled,
      @NotBlank String unmatchedCron,
      @NotBlank String eodCron
  ) {}

  public record Azure(Blob blob) {
    public record Blob(
        boolean enabled,
        String connectionString,
        @NotBlank String container,
        @NotBlank String prefix
    ) {}
  }
}
