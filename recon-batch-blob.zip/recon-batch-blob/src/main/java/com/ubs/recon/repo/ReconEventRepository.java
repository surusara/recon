package com.ubs.recon.repo;

import com.ubs.recon.model.ReconEvent;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ParameterizedPreparedStatementSetter;
import org.springframework.stereotype.Repository;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

@Repository
public class ReconEventRepository {

  private final JdbcTemplate jdbc;

  public ReconEventRepository(JdbcTemplate jdbc) {
    this.jdbc = jdbc;
  }

  public int batchInsert(List<ReconEvent> events) {
    if (events.isEmpty()) return 0;

    String sql = "INSERT INTO recon_event(trade_date, trade_id, version, flow_name, status, proc_ms, created_at, src_audit_id, source_name) " +
        "VALUES(?,?,?,?,?,?,?,?,?) ON CONFLICT DO NOTHING";

    int[][] counts = jdbc.batchUpdate(sql, events, 5000, new ParameterizedPreparedStatementSetter<>() {
      @Override
      public void setValues(PreparedStatement ps, ReconEvent e) throws SQLException {
        ps.setObject(1, e.tradeDate());
        ps.setString(2, e.tradeId());
        ps.setInt(3, e.version());
        ps.setString(4, e.flowName());
        ps.setString(5, e.status());
        if (e.procMs() == null) ps.setNull(6, java.sql.Types.BIGINT);
        else ps.setLong(6, e.procMs());
        ps.setObject(7, e.createdAt());
        ps.setLong(8, e.srcAuditId());
        ps.setString(9, e.sourceName());
      }
    });

    int total = 0;
    for (int[] batch : counts) for (int c : batch) total += c;
    return total;
  }
}
