package com.ubs.recon.model;

import java.time.OffsetDateTime;

public record Checkpoint(
    String sourceName,
    long lastSeenId,
    OffsetDateTime updatedAt
) {}
