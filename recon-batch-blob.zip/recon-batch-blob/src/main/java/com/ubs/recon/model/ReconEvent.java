package com.ubs.recon.model;

import java.time.LocalDate;
import java.time.OffsetDateTime;

public record ReconEvent(
    LocalDate tradeDate,
    String tradeId,
    int version,
    String flowName,
    String status,
    Long procMs,
    OffsetDateTime createdAt,
    long srcAuditId,
    String sourceName
) {}
