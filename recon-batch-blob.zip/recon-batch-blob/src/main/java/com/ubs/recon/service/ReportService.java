package com.ubs.recon.service;

import com.ubs.recon.ReconProperties;
import com.ubs.recon.blob.BlobSink;
import org.postgresql.PGConnection;
import org.postgresql.copy.CopyManager;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.datasource.DataSourceUtils;
import org.springframework.stereotype.Service;

import javax.sql.DataSource;
import java.io.OutputStream;
import java.sql.Connection;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

@Service
public class ReportService {

  private static final Logger log = LoggerFactory.getLogger(ReportService.class);
  private static final DateTimeFormatter DTF = DateTimeFormatter.ISO_LOCAL_DATE;

  private final DataSource reconDataSource;
  private final BlobSink blobSink;
  private final ReconProperties props;

  public ReportService(DataSource reconDataSource, BlobSink blobSink, ReconProperties props) {
    this.reconDataSource = reconDataSource;
    this.blobSink = blobSink;
    this.props = props;
  }

  public void exportUnmatched(LocalDate tradeDate) {
    export(tradeDate, true);
  }

  public void exportEndOfDay(LocalDate tradeDate) {
    export(tradeDate, false);
  }

  private void export(LocalDate tradeDate, boolean unmatchedOnly) {
    String prefix = props.azure().blob().prefix();
    String dateStr = DTF.format(tradeDate);
    String type = unmatchedOnly ? "unmatched" : "eod";

    // Example blob name: recon/2026-01-15/unmatched.csv
    String blobName = String.format("%s/%s/%s.csv", prefix, dateStr, type);

    String copySql = buildCopySql(tradeDate, unmatchedOnly);

    Connection conn = DataSourceUtils.getConnection(reconDataSource);
    try {
      conn.setAutoCommit(false);
      PGConnection pg = conn.unwrap(PGConnection.class);
      CopyManager copyManager = pg.getCopyAPI();

      try (OutputStream out = blobSink.open(blobName)) {
        long rows = copyManager.copyOut(copySql, out);
        out.flush();
        log.info("Exported {} rows to {}", rows, blobName);
      }

      conn.commit();
    } catch (Exception e) {
      try { conn.rollback(); } catch (Exception ignore) {}
      log.error("Report export failed (tradeDate={}, unmatchedOnly={}, blobName={})", tradeDate, unmatchedOnly, blobName, e);
    } finally {
      DataSourceUtils.releaseConnection(conn, reconDataSource);
    }
  }

  /**
   * CSV columns:
   * trade_date, trade_id, version, final_status, total_proc_ms, per_flow_proc_ms_json, missing_required_flows
   */
  private String buildCopySql(LocalDate tradeDate, boolean unmatchedOnly) {
    // For safety, embed the date as a SQL literal. (Alternatively: use a server-side prepared COPY via function.)
    String date = DTF.format(tradeDate);

    String filter = unmatchedOnly
        ? "WHERE success_count <> required_count"
        : "";

    return "COPY ( " +
        "  WITH required_flows AS ( " +
        "    SELECT flow_name " +
        "    FROM recon_expected_flow " +
        "    WHERE required = true " +
        "      AND effective_from <= DATE '" + date + "' " +
        "      AND (effective_to IS NULL OR effective_to >= DATE '" + date + "') " +
        "  ), required_count AS ( " +
        "    SELECT COUNT(*) AS required_count FROM required_flows " +
        "  ), latest_per_flow AS ( " +
        "    SELECT DISTINCT ON (trade_date, trade_id, version, flow_name) " +
        "           trade_date, trade_id, version, flow_name, status, proc_ms " +
        "    FROM recon_event " +
        "    WHERE trade_date = DATE '" + date + "' " +
        "    ORDER BY trade_date, trade_id, version, flow_name, src_audit_id DESC " +
        "  ), trade_rollup AS ( " +
        "    SELECT " +
        "      t.trade_date, t.trade_id, t.version, " +
        "      SUM(CASE WHEN t.status = 'SUCCESS' THEN 1 ELSE 0 END) AS success_count, " +
        "      SUM(COALESCE(t.proc_ms,0)) AS total_proc_ms, " +
        "      jsonb_object_agg(t.flow_name, COALESCE(t.proc_ms,0)) AS per_flow_proc_ms_json " +
        "    FROM latest_per_flow t " +
        "    GROUP BY t.trade_date, t.trade_id, t.version " +
        "  ), missing AS ( " +
        "    SELECT tr.trade_date, tr.trade_id, tr.version, " +
        "           array_agg(rf.flow_name ORDER BY rf.flow_name) AS missing_required_flows " +
        "    FROM trade_rollup tr " +
        "    CROSS JOIN required_flows rf " +
        "    LEFT JOIN latest_per_flow lpf " +
        "      ON lpf.trade_date = tr.trade_date AND lpf.trade_id = tr.trade_id AND lpf.version = tr.version AND lpf.flow_name = rf.flow_name " +
        "    WHERE lpf.flow_name IS NULL OR lpf.status <> 'SUCCESS' " +
        "    GROUP BY tr.trade_date, tr.trade_id, tr.version " +
        "  ), final AS ( " +
        "    SELECT " +
        "      tr.trade_date, tr.trade_id, tr.version, " +
        "      tr.success_count, rc.required_count, " +
        "      CASE WHEN tr.success_count = rc.required_count THEN 'MATCHED' ELSE 'UNMATCHED' END AS final_status, " +
        "      tr.total_proc_ms, tr.per_flow_proc_ms_json, " +
        "      COALESCE(m.missing_required_flows, ARRAY[]::text[]) AS missing_required_flows " +
        "    FROM trade_rollup tr " +
        "    CROSS JOIN required_count rc " +
        "    LEFT JOIN missing m " +
        "      ON m.trade_date = tr.trade_date AND m.trade_id = tr.trade_id AND m.version = tr.version " +
        "  ) " +
        "  SELECT trade_date, trade_id, version, final_status, total_proc_ms, per_flow_proc_ms_json, missing_required_flows " +
        "  FROM final " +
        "  " + filter +
        "  ORDER BY trade_id, version " +
        ") TO STDOUT WITH (FORMAT CSV, HEADER true, ENCODING 'UTF8')";
  }
}
