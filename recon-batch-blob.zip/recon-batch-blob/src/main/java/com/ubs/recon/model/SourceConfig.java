package com.ubs.recon.model;

public record SourceConfig(
    String sourceName,
    boolean enabled,
    String jdbcUrl,
    String dbUser,
    String dbPassword,
    String incrementalSql
) {}
