package com.ubs.recon.blob;

import com.azure.storage.blob.BlobContainerClient;
import com.azure.storage.blob.specialized.BlockBlobClient;
import com.azure.storage.blob.specialized.BlobOutputStream;

import java.io.OutputStream;

public class AzureBlobSink implements BlobSink {

  private final BlobContainerClient containerClient;

  public AzureBlobSink(BlobContainerClient containerClient) {
    this.containerClient = containerClient;
  }

  @Override
  public OutputStream open(String blobName) {
    BlockBlobClient blockBlobClient = containerClient.getBlobClient(blobName).getBlockBlobClient();
    // true = overwrite
    BlobOutputStream out = blockBlobClient.getBlobOutputStream(true);
    return out;
  }
}
