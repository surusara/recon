package com.ubs.recon.repo;

import com.ubs.recon.model.SourceConfig;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.sql.ResultSet;
import java.time.LocalDate;
import java.util.List;

@Repository
public class ReconConfigRepository {

  private final JdbcTemplate jdbc;

  public ReconConfigRepository(JdbcTemplate jdbc) {
    this.jdbc = jdbc;
  }

  public List<SourceConfig> loadEnabledSources() {
    String sql = "SELECT source_name, enabled, jdbc_url, db_user, db_password, incremental_sql FROM recon_source_config WHERE enabled = true";
    return jdbc.query(sql, (ResultSet rs, int rowNum) -> new SourceConfig(
        rs.getString("source_name"),
        rs.getBoolean("enabled"),
        rs.getString("jdbc_url"),
        rs.getString("db_user"),
        rs.getString("db_password"),
        rs.getString("incremental_sql")
    ));
  }

  /**
   * Required flow count can change over time (e.g., 13 -> 14) without code changes.
   */
  public int requiredFlowCount(LocalDate tradeDate) {
    String sql = "SELECT COUNT(*) FROM recon_expected_flow WHERE required=true AND effective_from <= ? AND (effective_to IS NULL OR effective_to >= ?)";
    Integer val = jdbc.queryForObject(sql, Integer.class, tradeDate, tradeDate);
    return val == null ? 0 : val;
  }
}
