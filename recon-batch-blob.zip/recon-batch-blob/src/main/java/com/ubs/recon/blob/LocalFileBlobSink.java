package com.ubs.recon.blob;

import java.io.BufferedOutputStream;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;

/**
 * Dev-only sink that writes to local disk. Useful when Azure blob is disabled.
 */
public class LocalFileBlobSink implements BlobSink {

  private final Path baseDir;

  public LocalFileBlobSink(Path baseDir) {
    this.baseDir = baseDir;
  }

  @Override
  public OutputStream open(String blobName) throws Exception {
    Path target = baseDir.resolve(blobName);
    Files.createDirectories(target.getParent());
    return new BufferedOutputStream(new FileOutputStream(target.toFile()));
  }
}
