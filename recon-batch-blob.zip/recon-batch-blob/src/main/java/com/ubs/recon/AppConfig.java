package com.ubs.recon;

import com.azure.storage.blob.BlobContainerClient;
import com.azure.storage.blob.BlobServiceClient;
import com.azure.storage.blob.BlobServiceClientBuilder;
import com.ubs.recon.blob.AzureBlobSink;
import com.ubs.recon.blob.BlobSink;
import com.ubs.recon.blob.LocalFileBlobSink;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.nio.file.Path;

@Configuration
@EnableConfigurationProperties(ReconProperties.class)
public class AppConfig {

  @Bean
  public BlobSink blobSink(ReconProperties props) {
    ReconProperties.Azure.Blob blob = props.azure().blob();
    if (!blob.enabled()) {
      return new LocalFileBlobSink(Path.of("./out/reports"));
    }

    BlobServiceClient serviceClient = new BlobServiceClientBuilder()
        .connectionString(blob.connectionString())
        .buildClient();

    BlobContainerClient container = serviceClient.getBlobContainerClient(blob.container());
    if (!container.exists()) {
      container.create();
    }
    return new AzureBlobSink(container);
  }
}
