package com.ubs.recon.service;

import com.ubs.recon.model.ReconEvent;
import com.ubs.recon.model.SourceConfig;
import com.ubs.recon.repo.CheckpointRepository;
import com.ubs.recon.repo.ReconConfigRepository;
import com.ubs.recon.repo.ReconEventRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.*;

@Service
public class SourcePollingService {

  private static final Logger log = LoggerFactory.getLogger(SourcePollingService.class);

  private final ReconConfigRepository configRepo;
  private final CheckpointRepository checkpointRepo;
  private final ReconEventRepository eventRepo;
  private final PartitionService partitionService;

  public SourcePollingService(
      ReconConfigRepository configRepo,
      CheckpointRepository checkpointRepo,
      ReconEventRepository eventRepo,
      PartitionService partitionService
  ) {
    this.configRepo = configRepo;
    this.checkpointRepo = checkpointRepo;
    this.eventRepo = eventRepo;
    this.partitionService = partitionService;
  }

  public void pollAllSources(int perSourceLimit, int maxParallel) {
    List<SourceConfig> sources = configRepo.loadEnabledSources();
    if (sources.isEmpty()) {
      log.info("No enabled sources in recon_source_config");
      return;
    }

    ExecutorService pool = Executors.newFixedThreadPool(Math.max(1, maxParallel));
    try {
      List<Future<Void>> futures = new ArrayList<>();
      for (SourceConfig s : sources) {
        futures.add(pool.submit(() -> {
          pollOneSource(s, perSourceLimit);
          return null;
        }));
      }
      for (Future<Void> f : futures) {
        try {
          f.get(30, TimeUnit.MINUTES);
        } catch (TimeoutException te) {
          log.error("Polling timed out", te);
        }
      }
    } catch (InterruptedException ie) {
      Thread.currentThread().interrupt();
    } finally {
      pool.shutdown();
    }
  }

  private void pollOneSource(SourceConfig src, int limit) {
    String sourceName = src.sourceName();
    long lastSeen = checkpointRepo.getLastSeenId(sourceName);

    List<ReconEvent> buffer = new ArrayList<>(Math.min(limit, 50_000));
    long maxSeenThisRun = lastSeen;

    try (Connection conn = DriverManager.getConnection(src.jdbcUrl(), src.dbUser(), src.dbPassword());
         PreparedStatement ps = conn.prepareStatement(src.incrementalSql())) {

      // Convention: first bind is last_seen_id, second is LIMIT
      ps.setLong(1, lastSeen);
      ps.setInt(2, limit);

      try (ResultSet rs = ps.executeQuery()) {
        while (rs.next()) {
          // The incremental_sql must SELECT these columns (exact aliases):
          // trade_date (date), trade_id (text), version (int), flow_name (text), status (text), proc_ms (bigint), src_audit_id (bigint)
          var tradeDate = rs.getDate("trade_date").toLocalDate();
          var tradeId = rs.getString("trade_id");
          var version = rs.getInt("version");
          var flowName = rs.getString("flow_name");
          var status = rs.getString("status");
          Long procMs = null;
          long pm = rs.getLong("proc_ms");
          if (!rs.wasNull()) procMs = pm;
          long srcAuditId = rs.getLong("src_audit_id");

          partitionService.ensurePartition(tradeDate);

          buffer.add(new ReconEvent(
              tradeDate,
              tradeId,
              version,
              flowName,
              status,
              procMs,
              OffsetDateTime.now(),
              srcAuditId,
              sourceName
          ));

          if (srcAuditId > maxSeenThisRun) {
            maxSeenThisRun = srcAuditId;
          }

          // Periodic flush to keep memory bounded
          if (buffer.size() >= 10_000) {
            flush(buffer, sourceName);
          }
        }
      }

      flush(buffer, sourceName);

      if (maxSeenThisRun > lastSeen) {
        checkpointRepo.upsertLastSeenId(sourceName, maxSeenThisRun);
      }

      log.info("Polled source={} lastSeen={} maxSeenThisRun={} insertedRows~={} ", sourceName, lastSeen, maxSeenThisRun, "(see DB)");

    } catch (Exception e) {
      log.error("Polling failed for source={}", sourceName, e);
    }
  }

  private void flush(List<ReconEvent> buffer, String sourceName) {
    if (buffer.isEmpty()) return;
    int inserted = eventRepo.batchInsert(buffer);
    log.info("Inserted {} recon_event rows for source={}", inserted, sourceName);
    buffer.clear();
  }
}
