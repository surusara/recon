package com.ubs.recon.service;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.HashSet;
import java.util.Set;

@Service
public class PartitionService {

  private final JdbcTemplate jdbc;
  private final Set<LocalDate> ensured = new HashSet<>();

  public PartitionService(JdbcTemplate jdbc) {
    this.jdbc = jdbc;
  }

  /**
   * Calls ensure_recon_partition(date) once per JVM for that date.
   */
  public synchronized void ensurePartition(LocalDate tradeDate) {
    if (tradeDate == null) return;
    if (ensured.contains(tradeDate)) return;
    jdbc.update("SELECT ensure_recon_partition(?)", tradeDate);
    ensured.add(tradeDate);
  }
}
