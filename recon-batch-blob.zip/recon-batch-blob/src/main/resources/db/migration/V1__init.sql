-- Recon DB schema

CREATE TABLE IF NOT EXISTS recon_event (
  trade_date       date        NOT NULL,
  trade_id         text        NOT NULL,
  version          int         NOT NULL,
  flow_name        text        NOT NULL,
  status           text        NOT NULL,
  proc_ms          bigint      NULL,
  created_at       timestamptz NOT NULL DEFAULT now(),
  src_audit_id     bigint      NOT NULL,
  source_name      text        NOT NULL,
  PRIMARY KEY (trade_date, trade_id, version, flow_name, src_audit_id, source_name)
) PARTITION BY RANGE (trade_date);

-- Checkpoint per microservice source (incremental polling)
CREATE TABLE IF NOT EXISTS recon_checkpoint (
  source_name   text PRIMARY KEY,
  last_seen_id  bigint NOT NULL,
  updated_at    timestamptz NOT NULL DEFAULT now()
);

-- Expected flows (controls required count dynamically)
CREATE TABLE IF NOT EXISTS recon_expected_flow (
  flow_name      text NOT NULL,
  required       boolean NOT NULL DEFAULT true,
  effective_from date NOT NULL DEFAULT CURRENT_DATE,
  effective_to   date NULL,
  PRIMARY KEY(flow_name, effective_from)
);

-- Source config: where/how to poll each microservice DB
CREATE TABLE IF NOT EXISTS recon_source_config (
  source_name   text PRIMARY KEY,
  enabled       boolean NOT NULL DEFAULT true,
  jdbc_url      text NOT NULL,
  db_user       text NOT NULL,
  db_password   text NOT NULL,
  -- Parameterized SQL (must output: trade_date, trade_id, version, flow_name, status, proc_ms, src_audit_id)
  -- It MUST include "WHERE <id_col> > ?" as the first bind parameter, and "LIMIT ?" as second.
  incremental_sql text NOT NULL
);

-- Helper: create daily partition if missing
CREATE OR REPLACE FUNCTION ensure_recon_partition(p_date date) RETURNS void AS $$
DECLARE
  p_start date := p_date;
  p_end   date := p_date + 1;
  p_name  text := 'recon_event_' || to_char(p_date, 'YYYY_MM_DD');
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_class c JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE c.relname = p_name AND n.nspname = current_schema()
  ) THEN
    EXECUTE format('CREATE TABLE %I PARTITION OF recon_event FOR VALUES FROM (%L) TO (%L)', p_name, p_start, p_end);
    EXECUTE format('CREATE INDEX %I ON %I (trade_date, trade_id, version)', 'ix_'||p_name||'_trade', p_name);
    EXECUTE format('CREATE INDEX %I ON %I (trade_date, flow_name)', 'ix_'||p_name||'_flow', p_name);
  END IF;
END;
$$ LANGUAGE plpgsql;

-- Optional: seed 13 flows (EDIT as needed)
-- INSERT INTO recon_expected_flow(flow_name, required, effective_from) VALUES
-- ('trade_ingestion', true, CURRENT_DATE),
-- ('trade_consumer', true, CURRENT_DATE),
-- ('settlement_obligation', true, CURRENT_DATE),
-- ('confirmation', true, CURRENT_DATE),
-- ('funding', true, CURRENT_DATE),
-- ('accounting', true, CURRENT_DATE);

