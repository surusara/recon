# Recon Batch → Postgres (partitioned) → CSV to Azure Blob (Postgres COPY streaming)

This Spring Boot (Java 21) project implements the **short-term reconciliation approach** we agreed:

1. **Every 10 minutes**: poll each microservice database **incrementally** (using `last_seen_id`).
2. Insert recon facts into a central **Postgres** table `recon_event` (**append-only**, partitioned by `trade_date`).
3. **Every 2 hours**: generate an **unmatched-only** CSV report.
4. **End of day**: generate a **full** CSV report.
5. Reports are written **streaming** to **Azure Blob Storage** using Postgres `COPY ... TO STDOUT` (no in-memory file).

> ✅ Safe for large datasets: neither Postgres nor JVM loads the full result set in memory.

---

## 1) Tech stack
- Java 21
- Spring Boot 3.3.x
- Postgres (recon DB)
- Azure Blob Storage (report output)

---

## 2) Database schema
Flyway migration creates:
- `recon_event` (partitioned by `trade_date`)
- `recon_checkpoint` (per source last seen id)
- `recon_expected_flow` (required flows, allows 13 → 14 without schema changes)
- `recon_source_config` (source polling config)
- `ensure_recon_partition(date)` function to create daily partitions on demand

See: `src/main/resources/db/migration/V1__init.sql`

---

## 3) Configure recon DB connection
Set env vars (local example):

```bash
export RECON_DB_URL=jdbc:postgresql://localhost:5432/recon
export RECON_DB_USER=recon
export RECON_DB_PASSWORD=recon
```

---

## 4) Configure Azure Blob output
Set:

```bash
export AZURE_STORAGE_CONNECTION_STRING='DefaultEndpointsProtocol=...'
export RECON_BLOB_CONTAINER='recon-reports'
export RECON_BLOB_PREFIX='recon'
```

If `RECON_BLOB_ENABLED=false`, reports are written under `./out/reports/...`.

---

## 5) Add a microservice source (polling config)
Each source inserts rows into `recon_event` by executing **incremental_sql** against the microservice DB.

### 5.1 Required output columns
Your `incremental_sql` **must return these column aliases**:
- `trade_date` (DATE)  ← from business table (your “trade date”)
- `trade_id` (TEXT)
- `version` (INT)
- `flow_name` (TEXT)   ← constant or derived
- `status` (TEXT)      ← e.g., SUCCESS / FAIL
- `proc_ms` (BIGINT)   ← per microservice processing time (nullable)
- `src_audit_id` (BIGINT) ← monotonically increasing ID for checkpointing

### 5.2 Parameter convention
The SQL **must bind parameters in this order**:
1) `last_seen_id` (BIGINT)
2) `limit` (INT)

### 5.3 Example insert
Example for a microservice whose audit table is `trade_audit` and business table `trade`:

```sql
INSERT INTO recon_source_config(
  source_name, enabled, jdbc_url, db_user, db_password, incremental_sql
) VALUES (
  'trade-consumer',
  true,
  'jdbc:postgresql://trade-consumer-db:5432/app',
  'app_user',
  '***DO_NOT_STORE_PLAINTEXT_IN_PROD***',
  $$
  SELECT
    t.trade_date                   AS trade_date,
    a.trade_id                     AS trade_id,
    a.version                      AS version,
    'trade_consumer'               AS flow_name,
    a.status                       AS status,
    a.processing_time_ms           AS proc_ms,
    a.id                           AS src_audit_id
  FROM trade_audit a
  JOIN trade t ON t.trade_id = a.trade_id AND t.version = a.version
  WHERE a.id > ?
  ORDER BY a.id
  LIMIT ?
  $$
);

-- Seed checkpoint (optional)
INSERT INTO recon_checkpoint(source_name, last_seen_id)
VALUES ('trade-consumer', 0)
ON CONFLICT DO NOTHING;
```

### Credentials / Key Vault note (enterprise)
In production, **do not store passwords in the table**.
Common patterns:
- store `db_password` as a Key Vault **secret name** (e.g. `kv:trade-consumer-db-pwd`) and resolve it in code
- or store **only** jdbc URL and user, and inject passwords via environment variables

This project keeps it simple for a working example; replace with your standard secrets approach.

---

## 6) Define “required flows” (the count is configurable)
Today you have 13 required microservices / steps.

Insert the required flows:

```sql
INSERT INTO recon_expected_flow(flow_name, required, effective_from)
VALUES
 ('trade_ingestion', true, CURRENT_DATE),
 ('trade_event', true, CURRENT_DATE),
 ('trade_consumer', true, CURRENT_DATE),
 ('settlement_obligation', true, CURRENT_DATE),
 ('confirmation', true, CURRENT_DATE),
 ('funding', true, CURRENT_DATE),
 ('accounting', true, CURRENT_DATE);
```

When you add a new microservice later, just insert one more row and the report logic automatically adjusts.

---

## 7) Report output and CSV columns
Reports are generated using Postgres `COPY (SELECT ...) TO STDOUT WITH CSV` and streamed directly to Blob.

### CSV columns
- `trade_date`
- `trade_id`
- `version`
- `final_status` (MATCHED / UNMATCHED)
- `total_proc_ms`
- `per_flow_proc_ms_json` (JSON map: flow_name → proc_ms)
- `missing_required_flows` (text array of flows missing success)

### Blob paths
- `recon/YYYY-MM-DD/unmatched.csv`
- `recon/YYYY-MM-DD/eod.csv`

---

## 8) Scheduling (cron)
Configured in `application.yml`:
- Poll: fixed delay (default 10 minutes)
- Unmatched report: every 2 hours
- EOD report: 23:55 daily

Override via env vars:
- `RECON_POLL_FIXED_DELAY_MS`
- `RECON_REPORT_UNMATCHED_CRON`
- `RECON_REPORT_EOD_CRON`

---

## 9) Run locally

```bash
mvn -q -DskipTests package
java -jar target/recon-batch-blob-0.1.0.jar
```

---

## 10) Future: switch from polling to event-driven
Later, each microservice can emit a small lineage event to Kafka:

```json
{ "tradeDate":"2026-01-15", "tradeId":"T123", "version":1, "flowName":"funding", "status":"SUCCESS", "procMs":12, "srcAuditId":999 }
```

You can then replace `SourcePollingService` with a Kafka consumer that writes the same `recon_event` rows.
Because `recon_event` is normalized (one row per flow), reporting SQL and CSV export remain unchanged.

---

## 11) Operational guidance
- Partition by `trade_date` keeps daily reports fast and makes retention easy (drop old partitions).
- Keep inserts batched (this project flushes every 10k records per source).
- Keep report generation streaming (COPY → BlobOutputStream) to avoid JVM memory spikes.

---

### Project layout
- `SourcePollingService` → polls each microservice DB incrementally
- `ReconEventRepository` → batch inserts into partitioned table
- `ReportService` → `COPY TO STDOUT` streaming to Azure Blob
- `Schedulers` → runs poll + reports

